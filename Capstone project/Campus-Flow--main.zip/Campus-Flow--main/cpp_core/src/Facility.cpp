#include "Facility.hpp"
#include <stdexcept>

namespace campusflow {

Facility::Facility(int id, std::string name, std::string category, std::string building,
                   std::string roomNumber, int capacity, int activeCounters,
                   OperatingHours hours, double avgServiceTimeMinutes)
    : id_(id), name_(std::move(name)), category_(std::move(category)),
      building_(std::move(building)), roomNumber_(std::move(roomNumber)),
      capacity_(capacity), activeCounters_(activeCounters),
      hours_(hours), isOperational_(true), avgServiceTimeMinutes_(avgServiceTimeMinutes) {
    if (capacity_ <= 0) {
        throw std::invalid_argument("Capacity must be positive");
    }
    if (activeCounters_ < 0) {
        throw std::invalid_argument("Active counters cannot be negative");
    }
}

void Facility::setCapacity(int cap) {
    if (cap <= 0) throw std::invalid_argument("Capacity must be positive");
    capacity_ = cap;
}

void Facility::setActiveCounters(int counters) {
    if (counters < 0) throw std::invalid_argument("Active counters cannot be negative");
    activeCounters_ = counters;
}

void Facility::setOperational(bool status) {
    isOperational_ = status;
}

void Facility::setAvgServiceTime(double minutes) {
    if (minutes <= 0.0) throw std::invalid_argument("Average service time must be positive");
    avgServiceTimeMinutes_ = minutes;
}

bool Facility::isWithinOperatingHours(int hour) const {
    return hour >= hours_.openHour && hour < hours_.closeHour;
}

} // namespace campusflow
