#pragma once

#include <string>
#include <vector>
#include <cmath>
#include <chrono>

namespace campusflow {

enum class CongestionLevel {
    Low,
    Moderate,
    High,
    Critical
};

std::string congestionLevelToString(CongestionLevel level);

struct CongestionThresholds {
    double lowMax = 0.40;      // <= 40% capacity
    double moderateMax = 0.70; // 41% - 70% capacity
    double highMax = 0.90;     // 71% - 90% capacity
    // > 90% is Critical
};

struct PredictionResult {
    double estimatedWaitMinutes;
    double baselineWaitMinutes;
    double confidenceLower;
    double confidenceUpper;
    CongestionLevel congestion;
    double congestionRatio;
    std::string timestamp;
    double historicalDemandRate;
    std::string formulaExplanation;
};

struct DatasetPoint {
    int peopleAhead;
    double avgServiceTime;
    int activeCounters;
    double historicalDemandRate;
    double actualObservedWaitMinutes;
};

class PredictionEngine {
private:
    CongestionThresholds thresholds_;
    double congestionCorrectionAlpha_; // default e.g. 0.15

public:
    explicit PredictionEngine(CongestionThresholds thresholds = CongestionThresholds(),
                              double alpha = 0.15);

    void setThresholds(const CongestionThresholds& th) { thresholds_ = th; }
    const CongestionThresholds& getThresholds() const { return thresholds_; }

    void setAlpha(double a) { congestionCorrectionAlpha_ = a; }
    double getAlpha() const { return congestionCorrectionAlpha_; }

    // Core Baseline Waiting-time formula
    // Estimated waiting time = (people ahead * avg service time) / active counters
    double calculateBaselineWait(int peopleAhead, double avgServiceTime, int activeCounters) const;

    // Adjusted waiting time with operating conditions and demand pressure
    PredictionResult predictWaitTime(int peopleAhead, double avgServiceTime, int activeCounters,
                                     int facilityCapacity, double historicalDemand,
                                     bool isOperational) const;

    // Moving average crowd forecasting over historical time slots
    double forecastDemandMovingAverage(const std::vector<double>& historicalCounts,
                                       const std::vector<double>& weights = {}) const;

    // Classify congestion level based on ratio = currentDemand / facilityCapacity
    CongestionLevel classifyCongestion(double demand, double capacity) const;

    // Evaluate Mean Absolute Error (MAE) on a validation dataset
    // Target: MAE <= 5.0 minutes
    double evaluateMAE(const std::vector<DatasetPoint>& testData, double capacity) const;
};

} // namespace campusflow
