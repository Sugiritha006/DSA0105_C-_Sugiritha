#include "User.hpp"
#include <stdexcept>

namespace campusflow {

std::string userRoleToString(UserRole role) {
    switch (role) {
        case UserRole::Student: return "student";
        case UserRole::FacilityManager: return "facility_manager";
        case UserRole::Administrator: return "admin";
        default: return "unknown";
    }
}

UserRole stringToUserRole(const std::string& roleStr) {
    if (roleStr == "student") return UserRole::Student;
    if (roleStr == "facility_manager") return UserRole::FacilityManager;
    if (roleStr == "admin") return UserRole::Administrator;
    throw std::invalid_argument("Unknown role string: " + roleStr);
}

User::User(int id, std::string username, std::string email, std::string passwordHash, UserRole role)
    : id_(id), username_(std::move(username)), email_(std::move(email)),
      passwordHash_(std::move(passwordHash)), role_(role) {}

Student::Student(int id, std::string username, std::string email, std::string passwordHash,
                 std::string studentIdNumber, std::string department)
    : User(id, std::move(username), std::move(email), std::move(passwordHash), UserRole::Student),
      studentIdNumber_(std::move(studentIdNumber)), department_(std::move(department)) {}

FacilityManager::FacilityManager(int id, std::string username, std::string email, std::string passwordHash,
                                 std::string assignedDepartment)
    : User(id, std::move(username), std::move(email), std::move(passwordHash), UserRole::FacilityManager),
      assignedDepartment_(std::move(assignedDepartment)) {}

Administrator::Administrator(int id, std::string username, std::string email, std::string passwordHash)
    : User(id, std::move(username), std::move(email), std::move(passwordHash), UserRole::Administrator) {}

} // namespace campusflow
