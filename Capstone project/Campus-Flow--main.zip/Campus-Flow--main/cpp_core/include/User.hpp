#pragma once

#include <string>
#include <chrono>

namespace campusflow {

enum class UserRole {
    Student,
    FacilityManager,
    Administrator
};

std::string userRoleToString(UserRole role);
UserRole stringToUserRole(const std::string& roleStr);

class User {
protected:
    int id_;
    std::string username_;
    std::string email_;
    std::string passwordHash_;
    UserRole role_;
    std::string createdAt_;

public:
    User(int id, std::string username, std::string email, std::string passwordHash, UserRole role);
    virtual ~User() = default;

    int getId() const { return id_; }
    const std::string& getUsername() const { return username_; }
    const std::string& getEmail() const { return email_; }
    const std::string& getPasswordHash() const { return passwordHash_; }
    UserRole getRole() const { return role_; }

    virtual bool canManageFacilities() const { return false; }
    virtual bool canManageUsers() const { return false; }
    virtual bool canBookFacilities() const { return true; }
};

class Student : public User {
private:
    std::string studentIdNumber_;
    std::string department_;

public:
    Student(int id, std::string username, std::string email, std::string passwordHash,
            std::string studentIdNumber, std::string department);

    const std::string& getStudentIdNumber() const { return studentIdNumber_; }
    const std::string& getDepartment() const { return department_; }

    bool canManageFacilities() const override { return false; }
    bool canManageUsers() const override { return false; }
    bool canBookFacilities() const override { return true; }
};

class FacilityManager : public User {
private:
    std::string assignedDepartment_;

public:
    FacilityManager(int id, std::string username, std::string email, std::string passwordHash,
                    std::string assignedDepartment);

    const std::string& getAssignedDepartment() const { return assignedDepartment_; }

    bool canManageFacilities() const override { return true; }
    bool canManageUsers() const override { return false; }
    bool canBookFacilities() const override { return true; }
};

class Administrator : public User {
public:
    Administrator(int id, std::string username, std::string email, std::string passwordHash);

    bool canManageFacilities() const override { return true; }
    bool canManageUsers() const override { return true; }
    bool canBookFacilities() const override { return true; }
};

} // namespace campusflow
