/**
 * CampusFlow Acceptance & Integration Test Suite
 * Covers all 10 Documented Test Scenarios and MAE Verification
 */

#include "User.hpp"
#include "Facility.hpp"
#include "Booking.hpp"
#include "QueueManager.hpp"
#include "PredictionEngine.hpp"
#include "ResourceScheduler.hpp"
#include "AuthenticationManager.hpp"

#include <iostream>
#include <cassert>
#include <vector>
#include <string>
#include <cmath>

using namespace campusflow;

void runScenario1_NormalQueue() {
    std::cout << "[Scenario 1] Normal queue operation ... ";
    QueueManager qm(1, 2, false);
    qm.enqueue(1, "Alice");
    qm.enqueue(2, "Bob");
    assert(qm.getWaitingCount() == 2);
    assert(qm.getPeopleAhead("Q-102") == 1);

    QueueEntry served("temp", 1, 0, "");
    bool called = qm.callNext(1, served);
    assert(called == true);
    assert(served.studentName == "Alice");
    assert(qm.getWaitingCount() == 1);
    std::cout << "PASSED\n";
}

void runScenario2_EmptyQueue() {
    std::cout << "[Scenario 2] Empty queue operation ... ";
    QueueManager qm(1, 2, false);
    assert(qm.getWaitingCount() == 0);

    QueueEntry served("temp", 1, 0, "");
    bool called = qm.callNext(1, served);
    assert(called == false); // Cannot serve when empty
    std::cout << "PASSED\n";
}

void runScenario3_HighDemandQueue() {
    std::cout << "[Scenario 3] High-demand queue (50 arrivals) ... ";
    QueueManager qm(1, 3, false);
    for (int i = 0; i < 50; ++i) {
        qm.enqueue(i + 1, "Student_" + std::to_string(i));
    }
    assert(qm.getWaitingCount() == 50);

    // Call first 10
    for (int i = 0; i < 10; ++i) {
        QueueEntry served("temp", 1, 0, "");
        assert(qm.callNext((i % 3) + 1, served));
    }
    assert(qm.getWaitingCount() == 40);
    std::cout << "PASSED\n";
}

void runScenario4_NoServiceCounters() {
    std::cout << "[Scenario 4] No available service counters (0 counters) ... ";
    QueueManager qm(1, 0, false);
    qm.enqueue(1, "David");

    QueueEntry served("temp", 1, 0, "");
    bool called = qm.callNext(1, served);
    assert(called == false); // Blocked because 0 counters are active

    PredictionEngine pe;
    PredictionResult pr = pe.predictWaitTime(1, 5.0, 0, 50, 10.0, true);
    assert(pr.estimatedWaitMinutes == -1.0); // Indefinite delay indicated by -1
    std::cout << "PASSED\n";
}

void runScenario5_FullFacilityCapacity() {
    std::cout << "[Scenario 5] Full facility capacity violation guard ... ";
    BookingManager bm;
    TimeSlot slot{10, 12, "2026-11-01"};
    int facilityCapacity = 20;

    // Fill capacity with 20 attendees
    bm.createBooking("BK-FULL-1", 1, 101, facilityCapacity, slot, 20);

    // Attempt to book 1 more seat in same overlapping slot
    bool caught = false;
    try {
        bm.createBooking("BK-FULL-2", 2, 101, facilityCapacity, slot, 1);
    } catch (const std::exception& e) {
        caught = true;
    }
    assert(caught == true); // Must reject capacity violation
    std::cout << "PASSED\n";
}

void runScenario6_DuplicateBookingAttempt() {
    std::cout << "[Scenario 6] Duplicate booking ID attempt ... ";
    BookingManager bm;
    TimeSlot slot{14, 16, "2026-11-02"};

    bm.createBooking("BK-DUP-100", 1, 102, 30, slot, 2);

    bool caught = false;
    try {
        bm.createBooking("BK-DUP-100", 2, 102, 30, slot, 2);
    } catch (const std::exception& e) {
        caught = true;
    }
    assert(caught == true); // Must reject duplicate ID
    std::cout << "PASSED\n";
}

void runScenario7_OverlappingBookingAttempt() {
    std::cout << "[Scenario 7] Overlapping booking attempt by same student ... ";
    BookingManager bm;
    TimeSlot slotA{10, 12, "2026-11-03"};
    TimeSlot slotB{11, 13, "2026-11-03"}; // Overlaps between 11 and 12

    bm.createBooking("BK-USER-1", 42, 101, 30, slotA, 1);

    bool caught = false;
    try {
        bm.createBooking("BK-USER-2", 42, 102, 30, slotB, 1);
    } catch (const std::exception& e) {
        caught = true;
    }
    assert(caught == true); // User cannot be in two places at once
    std::cout << "PASSED\n";
}

void runScenario8_BookingCancellation() {
    std::cout << "[Scenario 8] Booking cancellation and capacity recovery ... ";
    BookingManager bm;
    TimeSlot slot{13, 15, "2026-11-04"};
    int capacity = 10;

    bm.createBooking("BK-CAN-1", 10, 105, capacity, slot, 10);
    assert(bm.getActiveAttendeeCount(105, slot) == 10);

    // Cancel booking
    bool cancelled = bm.cancelBooking("BK-CAN-1", 10, false);
    assert(cancelled == true);
    assert(bm.getActiveAttendeeCount(105, slot) == 0); // Capacity freed

    // Subsequent booking should succeed now
    bm.createBooking("BK-CAN-2", 11, 105, capacity, slot, 5);
    assert(bm.getActiveAttendeeCount(105, slot) == 5);
    std::cout << "PASSED\n";
}

void runScenario9_SuddenDemandSpike() {
    std::cout << "[Scenario 9] Sudden increase in demand & congestion reclassification ... ";
    PredictionEngine pe;
    int capacity = 50;

    // Baseline low demand
    CongestionLevel cLow = pe.classifyCongestion(15, capacity); // 30%
    assert(cLow == CongestionLevel::Low);

    // Sudden spike to 48 arrivals
    CongestionLevel cHigh = pe.classifyCongestion(48, capacity); // 96%
    assert(cHigh == CongestionLevel::Critical);
    std::cout << "PASSED\n";
}

void runScenario10_AlternativeSlotRecommendation() {
    std::cout << "[Scenario 10] Alternative-slot recommendation when preferred is congested ... ";
    std::vector<Facility> facilities = {
        Facility(1, "Lab Alpha", "Computing Lab", "Hall A", "101", 10, 2, {8, 20}, 5.0),
        Facility(2, "Lab Beta", "Computing Lab", "Hall B", "201", 30, 3, {8, 20}, 5.0)
    };

    BookingManager bm;
    TimeSlot preferred{10, 12, "2026-11-05"};
    // Fill Lab Alpha to capacity in preferred slot
    bm.createBooking("BK-PREF-1", 1, 1, 10, preferred, 10);

    ResourceScheduler scheduler;
    AllocationRecommendation rec = scheduler.recommendSlots(
        facilities, bm.getAllBookings(), 5, preferred, "Computing Lab", false
    );

    assert(rec.preferredSlotFeasible == false); // Lab Alpha is full
    assert(!rec.alternativeRecommendations.empty());
    // An alternative slot (e.g. Lab Beta or later time) must be recommended
    assert(rec.alternativeRecommendations[0].isFeasible == true);
    std::cout << "PASSED (Recommended alternative: " << rec.alternativeRecommendations[0].facilityName << ")\n";
}

void runMAEBENCHMARK() {
    std::cout << "[Benchmark] Waiting-Time Prediction MAE Evaluation ... ";
    PredictionEngine pe;

    // Realistic representative test dataset with observed empirical service times
    std::vector<DatasetPoint> testDataset = {
        {2, 5.0, 2, 10.0, 5.2},
        {4, 6.0, 2, 18.0, 13.1},
        {6, 4.5, 3, 22.0, 9.8},
        {8, 7.0, 4, 30.0, 15.4},
        {1, 5.0, 1, 5.0, 5.5},
        {10, 5.0, 3, 40.0, 18.9},
        {3, 8.0, 2, 15.0, 13.0},
        {5, 6.5, 3, 25.0, 12.2},
        {12, 4.0, 4, 35.0, 13.5},
        {7, 5.5, 2, 28.0, 21.0}
    };

    double mae = pe.evaluateMAE(testDataset, 50.0);
    std::cout << "Measured MAE = " << mae << " minutes (Target <= 5.0 min) ... ";
    assert(mae <= 5.0);
    std::cout << "PASSED\n";
}

int main() {
    std::cout << "========================================================\n";
    std::cout << "CampusFlow Acceptance Test Suite (10 Scenarios + MAE)\n";
    std::cout << "========================================================\n";

    runScenario1_NormalQueue();
    runScenario2_EmptyQueue();
    runScenario3_HighDemandQueue();
    runScenario4_NoServiceCounters();
    runScenario5_FullFacilityCapacity();
    runScenario6_DuplicateBookingAttempt();
    runScenario7_OverlappingBookingAttempt();
    runScenario8_BookingCancellation();
    runScenario9_SuddenDemandSpike();
    runScenario10_AlternativeSlotRecommendation();
    runMAEBENCHMARK();

    std::cout << "========================================================\n";
    std::cout << "ALL 10 SCENARIOS & MAE BENCHMARK PASSED (100% SUCCESS)\n";
    std::cout << "Zero Booking Conflicts | Zero Capacity Violations\n";
    std::cout << "========================================================\n";
    return 0;
}
