#include "Booking.hpp"
#include <stdexcept>
#include <algorithm>

namespace campusflow {

std::string bookingStatusToString(BookingStatus status) {
    switch (status) {
        case BookingStatus::Confirmed: return "confirmed";
        case BookingStatus::Completed: return "completed";
        case BookingStatus::Cancelled: return "cancelled";
        default: return "unknown";
    }
}

BookingStatus stringToBookingStatus(const std::string& statusStr) {
    if (statusStr == "confirmed") return BookingStatus::Confirmed;
    if (statusStr == "completed") return BookingStatus::Completed;
    if (statusStr == "cancelled") return BookingStatus::Cancelled;
    throw std::invalid_argument("Unknown booking status: " + statusStr);
}

Booking::Booking(std::string bookingId, int userId, int facilityId,
                 TimeSlot slot, int attendeesCount, BookingStatus status)
    : bookingId_(std::move(bookingId)), userId_(userId), facilityId_(facilityId),
      slot_(std::move(slot)), attendeesCount_(attendeesCount), status_(status) {
    if (!slot_.isValid()) {
        throw std::invalid_argument("Invalid booking time slot specification");
    }
    if (attendeesCount_ <= 0) {
        throw std::invalid_argument("Attendees count must be greater than zero");
    }
}

int BookingManager::getActiveAttendeeCount(int facilityId, const TimeSlot& slot) const {
    int total = 0;
    for (const auto& b : bookings_) {
        if (b.getFacilityId() == facilityId && !b.isCancelled()) {
            if (b.getTimeSlot().overlapsWith(slot)) {
                total += b.getAttendeesCount();
            }
        }
    }
    return total;
}

Booking BookingManager::createBooking(const std::string& bookingId, int userId, int facilityId,
                                      int facilityCapacity, const TimeSlot& slot, int attendeesCount) {
    std::lock_guard<std::mutex> lock(bookingMutex_);

    if (!slot.isValid()) {
        throw std::invalid_argument("Time slot is invalid: startHour must precede endHour within [0, 24]");
    }
    if (attendeesCount <= 0) {
        throw std::invalid_argument("Booking attendees must be at least 1");
    }

    // 1. Check duplicate booking ID
    for (const auto& b : bookings_) {
        if (b.getBookingId() == bookingId) {
            throw std::runtime_error("Duplicate booking ID violation: " + bookingId);
        }
    }

    // 2. Check duplicate / conflicting user booking at same time
    for (const auto& b : bookings_) {
        if (b.getUserId() == userId && !b.isCancelled() && b.getTimeSlot().overlapsWith(slot)) {
            throw std::runtime_error("User has an overlapping booking at the requested time slot");
        }
    }

    // 3. Check facility capacity limit under concurrency/overlap
    int currentOccupancy = getActiveAttendeeCount(facilityId, slot);
    if (currentOccupancy + attendeesCount > facilityCapacity) {
        throw std::runtime_error("Capacity violation: Requested " + std::to_string(attendeesCount) +
                                 " seats, but facility only has " +
                                 std::to_string(facilityCapacity - currentOccupancy) +
                                 " available in this slot (Capacity: " + std::to_string(facilityCapacity) + ")");
    }

    Booking newBooking(bookingId, userId, facilityId, slot, attendeesCount, BookingStatus::Confirmed);
    bookings_.push_back(newBooking);
    return newBooking;
}

bool BookingManager::cancelBooking(const std::string& bookingId, int requestUserId, bool isAdmin) {
    std::lock_guard<std::mutex> lock(bookingMutex_);
    for (auto& b : bookings_) {
        if (b.getBookingId() == bookingId) {
            if (!isAdmin && b.getUserId() != requestUserId) {
                throw std::runtime_error("Unauthorized: Cannot cancel another user's booking");
            }
            if (b.isCancelled()) {
                return false;
            }
            b.setStatus(BookingStatus::Cancelled);
            return true;
        }
    }
    return false;
}

std::vector<Booking> BookingManager::getBookingsByFacility(int facilityId) const {
    std::lock_guard<std::mutex> lock(bookingMutex_);
    std::vector<Booking> res;
    for (const auto& b : bookings_) {
        if (b.getFacilityId() == facilityId) {
            res.push_back(b);
        }
    }
    return res;
}

std::vector<Booking> BookingManager::getBookingsByUser(int userId) const {
    std::lock_guard<std::mutex> lock(bookingMutex_);
    std::vector<Booking> res;
    for (const auto& b : bookings_) {
        if (b.getUserId() == userId) {
            res.push_back(b);
        }
    }
    return res;
}

} // namespace campusflow
