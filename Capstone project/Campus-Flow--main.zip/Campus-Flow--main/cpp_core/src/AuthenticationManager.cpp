#include "AuthenticationManager.hpp"
#include <stdexcept>
#include <sstream>
#include <iomanip>

namespace campusflow {

// Simple, reproducible SHA-256 simulation hash with constant salt for portable C++ builds
std::string AuthenticationManager::hashPasswordWithSalt(const std::string& password, const std::string& salt) {
    std::string combined = salt + ":" + password + ":cf_salt_2026";
    // 64-bit FNV-1a variant combined hash for cross-platform deterministic output
    uint64_t hash = 14695981039346656037ULL;
    for (char c : combined) {
        hash ^= static_cast<uint64_t>(c);
        hash *= 1099511628211ULL;
    }
    std::stringstream ss;
    ss << "sha256$" << salt << "$" << std::hex << std::setfill('0') << std::setw(16) << hash;
    return ss.str();
}

AuthenticationManager::AuthenticationManager() {
    // Seed initial users for all three roles
    registerUser("admin", "admin@campusflow.edu", "AdminSecure#2026", UserRole::Administrator);
    registerUser("prof_miller", "miller@campusflow.edu", "ManagerPass#1", UserRole::FacilityManager, "Computing & Engineering");
    registerUser("alex_chen", "alex.chen@campusflow.edu", "StudentPass#1", UserRole::Student, "STU-8821", "Computer Science");
}

std::shared_ptr<User> AuthenticationManager::registerUser(
    const std::string& username, const std::string& email,
    const std::string& rawPassword, UserRole role,
    const std::string& extraField1, const std::string& extraField2) {

    std::lock_guard<std::mutex> lock(authMutex_);

    for (const auto& u : users_) {
        if (u->getUsername() == username) {
            throw std::runtime_error("Registration conflict: Username already taken.");
        }
        if (u->getEmail() == email) {
            throw std::runtime_error("Registration conflict: Email already registered.");
        }
    }

    int nextId = static_cast<int>(users_.size()) + 1;
    std::string salt = "s" + std::to_string(nextId * 37);
    std::string passwordHash = hashPasswordWithSalt(rawPassword, salt);

    std::shared_ptr<User> newUser;
    switch (role) {
        case UserRole::Student:
            newUser = std::make_shared<Student>(nextId, username, email, passwordHash,
                                                extraField1.empty() ? ("STU-" + std::to_string(nextId + 1000)) : extraField1,
                                                extraField2.empty() ? "General Studies" : extraField2);
            break;
        case UserRole::FacilityManager:
            newUser = std::make_shared<FacilityManager>(nextId, username, email, passwordHash,
                                                        extraField1.empty() ? "Campus Operations" : extraField1);
            break;
        case UserRole::Administrator:
            newUser = std::make_shared<Administrator>(nextId, username, email, passwordHash);
            break;
    }

    users_.push_back(newUser);
    return newUser;
}

std::optional<AuthToken> AuthenticationManager::login(const std::string& usernameOrEmail, const std::string& rawPassword) {
    std::lock_guard<std::mutex> lock(authMutex_);

    for (const auto& u : users_) {
        if (u->getUsername() == usernameOrEmail || u->getEmail() == usernameOrEmail) {
            std::string salt = "s" + std::to_string(u->getId() * 37);
            std::string calculatedHash = hashPasswordWithSalt(rawPassword, salt);
            if (calculatedHash == u->getPasswordHash()) {
                // Generate token
                std::string tokenStr = "cf_tok_" + std::to_string(u->getId()) + "_" + std::to_string(users_.size() + 100);
                AuthToken token{tokenStr, u->getId(), u->getRole(), "2026-12-31T23:59:59Z"};
                activeSessions_[tokenStr] = token;
                return token;
            } else {
                return std::nullopt; // Bad password
            }
        }
    }
    return std::nullopt; // User not found
}

std::optional<AuthToken> AuthenticationManager::validateToken(const std::string& token) const {
    std::lock_guard<std::mutex> lock(authMutex_);
    auto it = activeSessions_.find(token);
    if (it != activeSessions_.end()) {
        return it->second;
    }
    return std::nullopt;
}

bool AuthenticationManager::hasPermission(const std::string& token, UserRole requiredRole) const {
    auto session = validateToken(token);
    if (!session.has_value()) return false;

    // Administrator has all permissions
    if (session->role == UserRole::Administrator) return true;

    // Facility manager has facility and student permissions
    if (session->role == UserRole::FacilityManager && requiredRole != UserRole::Administrator) return true;

    // Student has student permissions only
    return session->role == requiredRole;
}

void AuthenticationManager::revokeToken(const std::string& token) {
    std::lock_guard<std::mutex> lock(authMutex_);
    activeSessions_.erase(token);
}

std::shared_ptr<User> AuthenticationManager::getUserById(int userId) const {
    std::lock_guard<std::mutex> lock(authMutex_);
    for (const auto& u : users_) {
        if (u->getId() == userId) return u;
    }
    return nullptr;
}

} // namespace campusflow
