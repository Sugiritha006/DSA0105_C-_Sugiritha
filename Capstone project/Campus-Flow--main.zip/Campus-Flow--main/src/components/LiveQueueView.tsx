import React, { useState } from 'react';
import { Facility, QueueTicket, ServiceCounter, User, normalizeRole } from '../types/campus';
import {
  Users,
  Clock,
  Layers,
  ChevronRight,
  CheckCircle2,
  AlertTriangle,
  Play,
  Check,
  X,
  Power,
  RotateCcw,
  Shield,
  Lock,
  QrCode,
  Ticket,
  PlusCircle,
  Coffee,
  BookOpen,
  Building,
  Cpu,
  Pause,
  Sliders,
  Send,
  EyeOff,
} from 'lucide-react';

interface LiveQueueViewProps {
  facilities: Facility[];
  queueTickets: QueueTicket[];
  serviceCounters: ServiceCounter[];
  currentUser: User;
  onJoinQueue: (facilityId: number, priority?: number) => void;
  onCancelQueueTicket: (ticketId: string) => void;
  onCallNextTicket: (facilityId: number, counterId: number) => void;
  onCompleteService: (ticketId: string) => void;
  onToggleCounter: (counterId: number) => void;
  onPauseResumeQueue?: (facilityId: number, paused: boolean) => void;
  onOverrideTicketSlot?: (ticketId: string, newPriority: number, reason: string) => void;
}

export const LiveQueueView: React.FC<LiveQueueViewProps> = ({
  facilities,
  queueTickets,
  serviceCounters,
  currentUser,
  onJoinQueue,
  onCancelQueueTicket,
  onCallNextTicket,
  onCompleteService,
  onToggleCounter,
  onPauseResumeQueue,
  onOverrideTicketSlot,
}) => {
  const normRole = normalizeRole(currentUser.role);

  // Scoped default facility for Faculty
  const defaultFacility = facilities.find((f) => {
    if (normRole === 'faculty' && currentUser.department) {
      return f.department === currentUser.department;
    }
    return true;
  }) || facilities[0];

  const [selectedFacilityId, setSelectedFacilityId] = useState<number>(defaultFacility.id);
  const [overrideModalTicket, setOverrideModalTicket] = useState<QueueTicket | null>(null);
  const [overrideReason, setOverrideReason] = useState<string>('Faculty Office Hours Priority Review');
  const [isQueuePaused, setIsQueuePaused] = useState<Record<number, boolean>>({});

  const selectedFacility = facilities.find((f) => f.id === selectedFacilityId) || facilities[0];

  // Tickets for selected facility
  const facilityTickets = queueTickets.filter(
    (t) => t.facilityId === selectedFacility.id
  );

  const waitingTickets = facilityTickets.filter((t) => t.status === 'waiting');
  const servingTickets = facilityTickets.filter((t) => t.status === 'serving');

  // Counters for selected facility
  const facilityCounters = serviceCounters.filter(
    (c) => c.facilityId === selectedFacility.id
  );

  // Check if current user has an active ticket here
  const myTicket = facilityTickets.find(
    (t) => (t.userId === currentUser.id || (t.userUid && t.userUid === currentUser.uid)) &&
      (t.status === 'waiting' || t.status === 'serving')
  );

  const myPosition = myTicket && myTicket.status === 'waiting'
    ? waitingTickets.findIndex((t) => t.id === myTicket.id) + 1
    : 0;

  const peopleAhead = myPosition > 0 ? myPosition - 1 : 0;

  const handleToggleQueuePause = (facId: number) => {
    const nextState = !isQueuePaused[facId];
    setIsQueuePaused((prev) => ({ ...prev, [facId]: nextState }));
    if (onPauseResumeQueue) {
      onPauseResumeQueue(facId, nextState);
    }
  };

  const handleConfirmOverride = () => {
    if (overrideModalTicket && onOverrideTicketSlot) {
      onOverrideTicketSlot(overrideModalTicket.id, 1, overrideReason);
      setOverrideModalTicket(null);
    }
  };

  // Quick token shortcuts for student
  const quickTokenFacilities = facilities.filter((f) =>
    ['Canteen', 'Study Lounge', 'Student Services', 'Computing Lab'].includes(f.category)
  );

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span
              className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
                normRole === 'admin'
                  ? 'bg-purple-100 text-purple-800 border-purple-200'
                  : normRole === 'faculty'
                  ? 'bg-indigo-100 text-indigo-800 border-indigo-200'
                  : 'bg-emerald-100 text-emerald-800 border-emerald-200'
              }`}
            >
              {normRole === 'admin' ? 'Admin Global Queue Control' : normRole === 'faculty' ? 'Faculty Queue Management' : 'Student Live Queuing'}
            </span>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">
              Live Campus Queue & Service Dispatch
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {normRole === 'student'
              ? 'Real-time personal queue tokens, countdown wait estimations, and counter notifications.'
              : normRole === 'faculty'
              ? `Manage student lines, call patrons to consultation desks, and override appointments for ${currentUser.department || 'your department'}.`
              : 'Global queue orchestration, priority overrides, counter management, and system-wide dispatch.'}
          </p>
        </div>

        {/* Facility Selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs font-medium text-slate-600 whitespace-nowrap">
            Select Facility:
          </label>
          <select
            value={selectedFacilityId}
            onChange={(e) => setSelectedFacilityId(parseInt(e.target.value))}
            className="text-xs font-medium bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
          >
            {facilities.map((fac) => (
              <option key={fac.id} value={fac.id}>
                {fac.name} ({fac.category})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Facility Operational Strip & Pause Indicator */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
        <div>
          <div className="text-[11px] text-slate-500 font-medium">Facility Line Status</div>
          <div className="mt-1 flex items-center gap-2">
            <span
              className={`text-xs font-semibold ${
                isQueuePaused[selectedFacility.id]
                  ? 'text-amber-700'
                  : selectedFacility.isOperational
                  ? 'text-emerald-700'
                  : 'text-rose-700'
              }`}
            >
              {isQueuePaused[selectedFacility.id]
                ? 'Queue Temporarily Paused'
                : selectedFacility.isOperational
                ? 'Operational & Accepting'
                : 'Under Maintenance'}
            </span>
          </div>
        </div>

        <div>
          <div className="text-[11px] text-slate-500 font-medium">Active Service Desks</div>
          <div className="mt-1 font-mono tabular-nums text-sm font-semibold text-slate-800">
            {facilityCounters.filter((c) => c.isActive).length} of {facilityCounters.length} Open
          </div>
        </div>

        <div>
          <div className="text-[11px] text-slate-500 font-medium">Queue Backlog</div>
          <div className="mt-1 font-mono tabular-nums text-sm font-semibold text-slate-800">
            {waitingTickets.length} waiting · {servingTickets.length} in service
          </div>
        </div>

        <div>
          <div className="text-[11px] text-slate-500 font-medium">Avg Service Velocity</div>
          <div className="mt-1 font-mono tabular-nums text-sm font-semibold text-slate-800">
            {selectedFacility.avgServiceTimeMinutes.toFixed(1)} min / patron
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* STUDENT SPECIFIC: LIVE QUEUE STATUS & TOKEN GENERATOR                     */}
      {/* ========================================================================= */}
      {normRole === 'student' && (
        <div className="space-y-6">
          {/* Active Personal Queue Token Presentation */}
          {myTicket ? (
            <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-md border border-slate-800 relative overflow-hidden">
              <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 opacity-5 pointer-events-none">
                <QrCode className="w-64 h-64 text-white" />
              </div>

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Personal Active Token
                    </span>
                    <span className="text-xs text-slate-400">
                      Issued {new Date(myTicket.joinedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <div className="mt-3 flex items-baseline gap-4">
                    <span className="text-4xl font-extrabold font-mono tracking-tight text-white">
                      {myTicket.id}
                    </span>
                    <span
                      className={`text-xs px-2.5 py-1 rounded-full font-semibold ${
                        myTicket.status === 'serving'
                          ? 'bg-emerald-500 text-slate-950 animate-pulse'
                          : 'bg-slate-800 text-slate-200 border border-slate-700'
                      }`}
                    >
                      {myTicket.status === 'serving' ? 'NOW SERVING' : 'WAITING IN FIFO QUEUE'}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 mt-2 font-medium">
                    {myTicket.facilityName}
                  </p>

                  <div className="mt-4 flex flex-wrap items-center gap-4 text-xs">
                    {myTicket.status === 'waiting' ? (
                      <>
                        <div className="bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/80">
                          <span className="text-slate-400">Your Position:</span>{' '}
                          <strong className="text-emerald-400 font-mono">#{myPosition} in line</strong>
                        </div>
                        <div className="bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/80">
                          <span className="text-slate-400">People Ahead:</span>{' '}
                          <strong className="text-white font-mono">{peopleAhead}</strong>
                        </div>
                        <div className="bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/80">
                          <span className="text-slate-400">Est. Wait:</span>{' '}
                          <strong className="text-amber-300 font-mono">~{myTicket.estimatedWaitMinutes.toFixed(1)} mins</strong>
                        </div>
                      </>
                    ) : (
                      <div className="bg-emerald-950/80 border border-emerald-500/40 px-3.5 py-2 rounded-lg text-emerald-200 text-xs font-medium">
                        Please proceed to <strong>Counter Desk #{myTicket.assignedCounter || 1}</strong> now!
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row md:flex-col gap-2 shrink-0">
                  <button
                    onClick={() => onCancelQueueTicket(myTicket.id)}
                    className="px-4 py-2 text-xs font-semibold text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 rounded-lg transition-colors text-center"
                  >
                    Leave Queue
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Queue Token Generator for key campus facilities */
            <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div>
                  <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <Ticket className="w-4 h-4 text-slate-700" />
                    Generate Live Queue Token
                  </h2>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Select a facility below to take your position in the digital queue line.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-4">
                {quickTokenFacilities.map((fac) => {
                  const estWait = Math.round(
                    fac.activeCounters > 0 ? (5 * fac.avgServiceTimeMinutes) / fac.activeCounters : 15
                  );

                  return (
                    <div
                      key={fac.id}
                      className="border border-slate-200 hover:border-slate-400 rounded-xl p-4 flex flex-col justify-between bg-slate-50/50 transition-colors"
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono uppercase text-slate-500">
                            {fac.category}
                          </span>
                          <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                            ~{estWait}m wait
                          </span>
                        </div>
                        <h3 className="text-xs font-bold text-slate-900 mt-1 line-clamp-1">
                          {fac.name}
                        </h3>
                        <p className="text-[11px] text-slate-500 mt-0.5">{fac.building}</p>
                      </div>

                      <button
                        onClick={() => onJoinQueue(fac.id, 0)}
                        className="mt-4 w-full py-1.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <PlusCircle className="w-3.5 h-3.5" />
                        Get Queue Token
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* FACULTY / ADMIN SERVICE COUNTER CONTROL STRIP                             */}
      {/* ========================================================================= */}
      {normRole !== 'student' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Layers className="w-4 h-4 text-slate-700" />
                Service Counter Desk Management ({selectedFacility.name})
              </h2>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Dispatch next student, toggle counter availability, or mark consultations as completed.
              </p>
            </div>

            <div className="flex items-center gap-2">
              {/* Queue Pause / Resume button */}
              <button
                onClick={() => handleToggleQueuePause(selectedFacility.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg flex items-center gap-1.5 transition-colors ${
                  isQueuePaused[selectedFacility.id]
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300'
                }`}
              >
                {isQueuePaused[selectedFacility.id] ? (
                  <>
                    <Play className="w-3 h-3" />
                    Resume Queue Intake
                  </>
                ) : (
                  <>
                    <Pause className="w-3 h-3" />
                    Pause Queue Intake
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
            {facilityCounters.map((counter) => (
              <div
                key={counter.id}
                className={`border rounded-xl p-4 transition-all ${
                  counter.isActive
                    ? 'bg-white border-slate-200 shadow-2xs'
                    : 'bg-slate-50 border-slate-200/60 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-900">
                    Window #{counter.counterNumber}
                  </span>
                  <button
                    onClick={() => onToggleCounter(counter.id)}
                    className={`text-[10px] font-mono px-2 py-0.5 rounded transition-colors ${
                      counter.isActive
                        ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                        : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                    }`}
                  >
                    {counter.isActive ? 'Active' : 'Closed'}
                  </button>
                </div>

                <div className="text-xs text-slate-600 font-medium mt-1 truncate">
                  {counter.counterName}
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100">
                  <div className="text-[11px] text-slate-500">Currently Serving:</div>
                  <div className="mt-0.5 text-sm font-mono font-bold text-slate-900 flex items-center justify-between">
                    <span>{counter.currentServingTicket || 'Idle / Empty'}</span>
                    {counter.currentServingTicket && (
                      <button
                        onClick={() => onCompleteService(counter.currentServingTicket!)}
                        title="Mark Attendance & Completed"
                        className="text-[10px] px-2 py-0.5 bg-emerald-600 text-white rounded hover:bg-emerald-500 transition-colors flex items-center gap-1"
                      >
                        <Check className="w-2.5 h-2.5" />
                        Complete
                      </button>
                    )}
                  </div>
                </div>

                {counter.isActive && !counter.currentServingTicket && waitingTickets.length > 0 && (
                  <button
                    onClick={() => onCallNextTicket(selectedFacility.id, counter.id)}
                    className="mt-3 w-full py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded text-xs font-semibold flex items-center justify-center gap-1 transition-colors"
                  >
                    <Play className="w-3 h-3" />
                    Call Next Student
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* QUEUE WAITING LIST WITH PRIVACY MASKING                                  */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-4 h-4 text-slate-700" />
                Active FIFO Queue Line ({waitingTickets.length} waiting)
              </h2>
              {normRole === 'student' && (
                <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded flex items-center gap-1">
                  <EyeOff className="w-3 h-3" />
                  Peer identity masking active
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Strict First-In-First-Out service order enforced by the C++ queue engine.
            </p>
          </div>
        </div>

        {waitingTickets.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-500">
            No patrons waiting in queue for {selectedFacility.name}. The queue line is clear.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 mt-2">
            {waitingTickets.map((ticket, idx) => {
              const isMine =
                ticket.userId === currentUser.id ||
                (ticket.userUid && ticket.userUid === currentUser.uid);

              // Privacy Masking for Student Role
              const displayName =
                normRole !== 'student' || isMine
                  ? ticket.studentName
                  : `Student STU-*** (Ticket ${ticket.id})`;

              return (
                <div
                  key={ticket.id}
                  className={`py-3 px-2 flex items-center justify-between rounded-lg transition-colors ${
                    isMine ? 'bg-emerald-50/70 border border-emerald-200' : 'hover:bg-slate-50/50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-6 text-center font-mono font-bold text-xs text-slate-400">
                      #{idx + 1}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-slate-900">
                          {ticket.id}
                        </span>
                        <span className="text-xs text-slate-700 font-medium">
                          {displayName}
                        </span>
                        {isMine && (
                          <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                            YOU
                          </span>
                        )}
                        {ticket.priorityLevel > 0 && (
                          <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-amber-100 text-amber-800">
                            PRIORITY
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                        Joined {new Date(ticket.joinedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · Est. Wait: ~{ticket.estimatedWaitMinutes.toFixed(1)} mins
                      </div>
                    </div>
                  </div>

                  {/* Actions depending on role */}
                  <div className="flex items-center gap-2">
                    {normRole !== 'student' && (
                      <button
                        onClick={() => setOverrideModalTicket(ticket)}
                        className="text-[11px] font-medium text-slate-700 hover:text-slate-900 bg-slate-100 px-2.5 py-1 rounded transition-colors"
                      >
                        Override Slot
                      </button>
                    )}
                    {isMine && (
                      <button
                        onClick={() => onCancelQueueTicket(ticket.id)}
                        className="text-[11px] text-rose-600 hover:text-rose-700 font-medium px-2 py-1"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Appointment Slot Override Modal for Faculty/Admin */}
      {overrideModalTicket && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900">
                Override Queue Appointment Slot
              </h3>
              <button
                onClick={() => setOverrideModalTicket(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div>Target Ticket: <strong className="font-mono">{overrideModalTicket.id}</strong></div>
                <div>Student: <strong>{overrideModalTicket.studentName}</strong></div>
                <div>Facility: <strong>{overrideModalTicket.facilityName}</strong></div>
              </div>

              <div>
                <label className="font-semibold text-slate-800 block mb-1">
                  Reason for Slot Override / Expedited Priority:
                </label>
                <textarea
                  rows={3}
                  value={overrideReason}
                  onChange={(e) => setOverrideReason(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-lg focus:ring-1 focus:ring-slate-900"
                  placeholder="Document override justification for immutable audit trail..."
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => setOverrideModalTicket(null)}
                  className="px-3 py-1.5 text-slate-600 hover:text-slate-900 font-medium"
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmOverride}
                  className="px-4 py-1.5 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800"
                >
                  Confirm Override
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
