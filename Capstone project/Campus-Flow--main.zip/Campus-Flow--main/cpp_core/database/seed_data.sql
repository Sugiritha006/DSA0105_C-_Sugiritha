-- =====================================================================
-- CampusFlow: Comprehensive MySQL 8.x Seed Data
-- =====================================================================

USE campusflow;

-- Seed Users
INSERT INTO users (id, username, email, password_hash, role, student_id_number, department) VALUES
(1, 'admin', 'admin@campusflow.edu', 'sha256$s37$61849a6fe402a1d2', 'admin', NULL, 'Campus Information Technology'),
(2, 'prof_miller', 'miller@campusflow.edu', 'sha256$s74$7b219ac4092de10a', 'facility_manager', NULL, 'Electrical & Computer Engineering'),
(3, 'dr_sarah_vance', 'vance@campusflow.edu', 'sha256$s111$39ca504e229bf1a3', 'facility_manager', NULL, 'University Libraries'),
(4, 'alex_chen', 'alex.chen@campusflow.edu', 'sha256$s148$11a3c79d40fb7241', 'student', 'STU-2026-8812', 'Computer Science'),
(5, 'maya_patel', 'maya.p@campusflow.edu', 'sha256$s185$98ef412c9842a176', 'student', 'STU-2026-9043', 'Mechanical Engineering'),
(6, 'jordan_lee', 'jordan.lee@campusflow.edu', 'sha256$s222$44ac9018e47b2c55', 'student', 'STU-2026-7721', 'Biomedical Informatics');

-- Seed Facilities
INSERT INTO facilities (id, name, category, building, room_number, capacity, active_counters, is_operational, avg_service_time_minutes, image_url) VALUES
(1, 'Main Computing Lab (Turing Wing)', 'Computing Lab', 'Alan Turing Hall', 'TL-204', 45, 3, TRUE, 6.50, '/assets/images/facility_computing_lab.jpg'),
(2, 'Collaborative Library Commons', 'Study Lounge', 'Williamson Library', 'WL-110', 80, 4, TRUE, 4.20, '/assets/images/facility_study_hub.jpg'),
(3, 'Hardware & Robotics Prototyping Lab', 'Maker Space', 'Engineering Quad', 'EQ-015', 25, 2, TRUE, 12.00, '/assets/images/campus_facility_hero.jpg'),
(4, 'Graduate Research Study Pods', 'Quiet Study', 'Science Center', 'SC-302', 18, 1, TRUE, 5.00, '/assets/images/facility_study_pods.jpg'),
(5, 'Academic Advising & Registrar Desk', 'Student Services', 'Administration Center', 'AC-101', 30, 3, TRUE, 8.50, '/assets/images/facility_academic_advising.jpg');

-- Seed Operating Hours (Monday through Friday 8am to 10pm)
INSERT INTO facility_operating_hours (facility_id, day_of_week, open_time, close_time) VALUES
(1, 1, '08:00:00', '22:00:00'), (1, 2, '08:00:00', '22:00:00'), (1, 3, '08:00:00', '22:00:00'), (1, 4, '08:00:00', '22:00:00'), (1, 5, '08:00:00', '20:00:00'),
(2, 1, '07:00:00', '23:00:00'), (2, 2, '07:00:00', '23:00:00'), (2, 3, '07:00:00', '23:00:00'), (2, 4, '07:00:00', '23:00:00'), (2, 5, '07:00:00', '21:00:00'),
(3, 1, '09:00:00', '18:00:00'), (3, 2, '09:00:00', '18:00:00'), (3, 3, '09:00:00', '18:00:00'), (3, 4, '09:00:00', '18:00:00'), (3, 5, '09:00:00', '17:00:00'),
(4, 1, '08:00:00', '20:00:00'), (4, 2, '08:00:00', '20:00:00'), (4, 3, '08:00:00', '20:00:00'), (4, 4, '08:00:00', '20:00:00'), (4, 5, '08:00:00', '18:00:00'),
(5, 1, '09:00:00', '17:00:00'), (5, 2, '09:00:00', '17:00:00'), (5, 3, '09:00:00', '17:00:00'), (5, 4, '09:00:00', '17:00:00'), (5, 5, '09:00:00', '16:00:00');

-- Seed Service Counters
INSERT INTO service_counters (id, facility_id, counter_number, counter_name, is_active) VALUES
(1, 1, 1, 'Station 1 - High-Spec Linux GPU Cluster', TRUE),
(2, 1, 2, 'Station 2 - AI Deep Learning Bench', TRUE),
(3, 1, 3, 'Station 3 - Software Dev Workstation', TRUE),
(4, 2, 1, 'Desk A - Circulation & Collaborative Pod 1', TRUE),
(5, 2, 2, 'Desk B - Collaborative Pod 2', TRUE),
(6, 2, 3, 'Desk C - Media Editing Suite', TRUE),
(7, 2, 4, 'Desk D - General Help & Reserved Seats', TRUE),
(8, 3, 1, 'Bench 1 - PCB Soldering & Scope Station', TRUE),
(9, 3, 2, 'Bench 2 - Rapid 3D Printing & Laser Cutter', TRUE),
(10, 5, 1, 'Advising Window 1 - Course Registration', TRUE),
(11, 5, 2, 'Advising Window 2 - Degree Audits & Holds', TRUE),
(12, 5, 3, 'Advising Window 3 - Financial Aid Verification', TRUE);

-- Seed Initial Bookings
INSERT INTO bookings (id, booking_reference, user_id, facility_id, booking_date, start_hour, end_hour, attendees_count, status, notes) VALUES
(1, 'BK-2026-101', 4, 1, '2026-10-23', 10, 12, 1, 'confirmed', 'CompSci 401 Final Project GPU Training'),
(2, 'BK-2026-102', 5, 2, '2026-10-23', 14, 16, 4, 'confirmed', 'Robotics Senior Design Group Study'),
(3, 'BK-2026-103', 6, 3, '2026-10-23', 11, 13, 2, 'confirmed', 'Bio-sensor circuit testing'),
(4, 'BK-2026-104', 4, 4, '2026-10-24', 9, 11, 1, 'confirmed', 'Thesis writing session');

-- Seed Initial Queue Entries
INSERT INTO queue_entries (id, queue_ticket_id, facility_id, user_id, student_name, priority_level, status, estimated_wait_minutes, joined_at) VALUES
(1, 'QF-101', 1, 4, 'Alex Chen', 0, 'serving', 0.0, NOW() - INTERVAL 12 MINUTE),
(2, 'QF-102', 1, 5, 'Maya Patel', 0, 'waiting', 4.3, NOW() - INTERVAL 8 MINUTE),
(3, 'QF-103', 1, 6, 'Jordan Lee', 0, 'waiting', 8.7, NOW() - INTERVAL 3 MINUTE),
(4, 'QL-201', 2, 4, 'Alex Chen', 0, 'serving', 0.0, NOW() - INTERVAL 15 MINUTE),
(5, 'QL-202', 2, 5, 'Maya Patel', 0, 'waiting', 2.1, NOW() - INTERVAL 4 MINUTE);

-- Seed Demand History for Forecasting Moving Averages
INSERT INTO demand_history (facility_id, date_recorded, time_slot_hour, total_arrivals, peak_queue_length, avg_observed_wait_minutes) VALUES
(1, '2026-10-20', 9, 14, 4, 4.8), (1, '2026-10-20', 10, 26, 8, 9.2), (1, '2026-10-20', 11, 38, 12, 14.5),
(1, '2026-10-20', 14, 42, 15, 18.0), (1, '2026-10-20', 15, 34, 10, 11.4),
(1, '2026-10-21', 9, 16, 5, 5.1), (1, '2026-10-21', 10, 29, 9, 10.3), (1, '2026-10-21', 11, 40, 14, 16.2),
(1, '2026-10-21', 14, 44, 16, 19.1), (1, '2026-10-21', 15, 32, 9, 10.8);

-- Seed Representative Test Prediction Data with MAE Audit Grounding
INSERT INTO prediction_records (facility_id, predicted_wait_minutes, actual_wait_minutes, absolute_error_minutes, congestion_level, active_counters_at_prediction, people_ahead_at_prediction) VALUES
(1, 5.4, 5.2, 0.2, 'Low', 2, 2),
(1, 13.8, 13.1, 0.7, 'Moderate', 2, 4),
(1, 10.1, 9.8, 0.3, 'Moderate', 3, 6),
(1, 16.2, 15.4, 0.8, 'High', 4, 8),
(1, 5.8, 5.5, 0.3, 'Low', 1, 1),
(1, 19.4, 18.9, 0.5, 'Critical', 3, 10),
(1, 13.5, 13.0, 0.5, 'Moderate', 2, 3),
(1, 12.9, 12.2, 0.7, 'Moderate', 3, 5),
(1, 14.1, 13.5, 0.6, 'High', 4, 12),
(1, 21.6, 21.0, 0.6, 'Critical', 2, 7);

-- Seed Audit Logs
INSERT INTO audit_logs (user_id, action_type, entity_name, entity_id, details) VALUES
(1, 'SYSTEM_INIT', 'SYSTEM', 'SYS-01', 'CampusFlow C++ Core and MySQL 8.x schemas successfully initialized.'),
(2, 'FACILITY_UPDATE', 'FACILITY', '1', 'Facility Manager prof_miller configured 3 active counters in Alan Turing Wing.'),
(4, 'BOOKING_CREATE', 'BOOKING', 'BK-2026-101', 'Student alex_chen booked Turing Wing Station 1 for 1 attendee.'),
(4, 'QUEUE_JOIN', 'QUEUE', 'QF-101', 'Student alex_chen joined FIFO queue for Turing Wing (Ticket QF-101).');
