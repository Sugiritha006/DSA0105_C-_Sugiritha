#include "ResourceScheduler.hpp"
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <cmath>

namespace campusflow {

ResourceScheduler::ResourceScheduler(SchedulerWeights weights) : weights_(weights) {}

double ResourceScheduler::computeWeightedScore(int availableCapacity, int totalCapacity,
                                               double predictedWaitMinutes, double expectedDemand,
                                               double utilizationRate) const {
    if (totalCapacity <= 0) return 0.0;

    // Component 1: Availability ratio (0 to 1) -> higher is better
    double availRatio = static_cast<double>(availableCapacity) / static_cast<double>(totalCapacity);

    // Component 2: Normalized wait time score -> lower wait time is better (max cap at 60 mins)
    double waitScore = std::max(0.0, 1.0 - (predictedWaitMinutes / 60.0));

    // Component 3: Demand headroom score -> lower historical congestion is better
    double demandRatio = std::min(1.0, expectedDemand / static_cast<double>(totalCapacity));
    double demandScore = 1.0 - demandRatio;

    // Component 4: Campus load balancing -> lower current utilization is better to prevent hotspots
    double utilScore = 1.0 - std::min(1.0, utilizationRate);

    double totalScore = (weights_.availabilityWeight * availRatio) +
                        (weights_.waitTimeWeight * waitScore) +
                        (weights_.demandWeight * demandScore) +
                        (weights_.utilizationWeight * utilScore);

    return std::max(0.0, std::min(1.0, totalScore));
}

double ResourceScheduler::computeGreedyScore(int availableCapacity) const {
    // Pure greedy: strictly prefers whatever has maximum instantaneous raw seats
    return static_cast<double>(availableCapacity);
}

AllocationRecommendation ResourceScheduler::recommendSlots(
    const std::vector<Facility>& facilities,
    const std::vector<Booking>& existingBookings,
    int requestedAttendees,
    const TimeSlot& preferredSlot,
    const std::string& preferredCategory,
    bool useGreedyBaseline) const {

    AllocationRecommendation result;
    result.algorithmUsed = useGreedyBaseline ? "GreedyBaseline" : "WeightedMultiFactor";

    // Standard campus testing hours: 8 to 20
    const int startHourRange = 8;
    const int endHourRange = 20;
    const int slotDuration = preferredSlot.endHour - preferredSlot.startHour;

    for (const auto& fac : facilities) {
        if (!fac.isOperational()) continue;
        if (!preferredCategory.empty() && fac.getCategory() != preferredCategory) continue;

        // Examine adjacent and daytime slots on preferred date
        for (int h = startHourRange; h <= (endHourRange - slotDuration); ++h) {
            TimeSlot candidateSlot{h, h + slotDuration, preferredSlot.date};

            // 1. Check operating hours
            if (!fac.isWithinOperatingHours(candidateSlot.startHour) ||
                !fac.isWithinOperatingHours(candidateSlot.endHour - 1)) {
                continue;
            }

            // 2. Count active bookings in this candidate slot
            int occupied = 0;
            for (const auto& b : existingBookings) {
                if (b.getFacilityId() == fac.getId() && !b.isCancelled()) {
                    if (b.getTimeSlot().overlapsWith(candidateSlot)) {
                        occupied += b.getAttendeesCount();
                    }
                }
            }

            int available = fac.getCapacity() - occupied;
            bool feasible = (available >= requestedAttendees);

            // Simulation metrics for wait & demand
            double utilRate = static_cast<double>(occupied) / static_cast<double>(fac.getCapacity());
            double simDemand = occupied * 1.1 + 2.0;
            double predWait = (fac.getActiveCounters() > 0)
                ? (occupied * fac.getAvgServiceTimeMinutes() / fac.getActiveCounters())
                : 99.0;

            SlotCandidate cand;
            cand.facilityId = fac.getId();
            cand.facilityName = fac.getName();
            cand.category = fac.getCategory();
            cand.slot = candidateSlot;
            cand.availableCapacity = available;
            cand.totalCapacity = fac.getCapacity();
            cand.predictedWaitMinutes = predWait;
            cand.expectedDemand = simDemand;
            cand.utilizationRate = utilRate;
            cand.isFeasible = feasible;

            if (useGreedyBaseline) {
                cand.score = feasible ? computeGreedyScore(available) : -1.0;
            } else {
                cand.score = feasible
                    ? computeWeightedScore(available, fac.getCapacity(), predWait, simDemand, utilRate)
                    : 0.0;
            }

            std::ostringstream reasonOss;
            if (!feasible) {
                reasonOss << "Rejected: Capacity exceeded (Requires " << requestedAttendees
                          << ", available " << available << ").";
            } else {
                reasonOss << "Feasible: " << available << "/" << fac.getCapacity()
                          << " seats free, predicted queue wait " << std::fixed
                          << std::setprecision(1) << predWait << " min, load util "
                          << static_cast<int>(utilRate * 100) << "%.";
            }
            cand.reason = reasonOss.str();

            // Check if this candidate is the user's preferred slot
            if (candidateSlot.startHour == preferredSlot.startHour &&
                candidateSlot.endHour == preferredSlot.endHour &&
                fac.getId() == facilities.front().getId()) {
                result.preferredSlotEvaluation = cand;
                result.preferredSlotFeasible = feasible;
            }

            if (feasible) {
                result.rankedCandidates.push_back(cand);
            }
        }
    }

    // Sort ranked candidates descending by score
    std::sort(result.rankedCandidates.begin(), result.rankedCandidates.end(),
              [](const SlotCandidate& a, const SlotCandidate& b) {
                  return a.score > b.score;
              });

    // Provide top 3 alternative recommendations
    for (size_t i = 0; i < result.rankedCandidates.size() && i < 3; ++i) {
        result.alternativeRecommendations.push_back(result.rankedCandidates[i]);
    }

    if (useGreedyBaseline) {
        result.comparisonNotes = "Greedy baseline selected purely by instantaneous available seats. It does not penalize queue congestion or balance campus utilization.";
    } else {
        result.comparisonNotes = "Weighted multi-factor model scored options balancing capacity headroom (35%), minimum queue latency (25%), demand smoothing (20%), and campus load balancing (20%).";
    }

    return result;
}

} // namespace campusflow
