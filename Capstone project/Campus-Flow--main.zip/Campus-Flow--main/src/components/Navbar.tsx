import React, { useState } from 'react';
import { User, UserRole, normalizeRole } from '../types/campus';
import {
  Layers,
  UserCircle,
  Bell,
  ChevronDown,
  Shield,
  LogIn,
  LogOut,
  Flame,
  Check,
  Sparkles,
} from 'lucide-react';

interface NavbarProps {
  currentUser: User;
  onSelectUser: (user: User) => void;
  availableUsers: User[];
  activeTab: string;
  onSelectTab: (tab: string) => void;
  onGoogleSignIn: () => void;
  onSignOut: () => void;
  isFirebaseUser: boolean;
  emergencyActive?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onSelectUser,
  availableUsers,
  activeTab,
  onSelectTab,
  onGoogleSignIn,
  onSignOut,
  isFirebaseUser,
  emergencyActive,
}) => {
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const normRole = normalizeRole(currentUser.role);

  // Dynamic Navigation tabs per role
  const getNavItems = () => {
    if (normRole === 'student') {
      return [
        { id: 'facilities', label: 'Facilities & Spaces' },
        { id: 'queues', label: 'My Queues & Tokens' },
        { id: 'predictions', label: 'Crowd Insights' },
        { id: 'my_bookings', label: 'My Bookings' },
      ];
    }
    if (normRole === 'faculty') {
      return [
        { id: 'queues', label: 'Department Queues' },
        { id: 'allocator', label: 'Resource Allocation' },
        { id: 'predictions', label: 'Departmental Footfall' },
        { id: 'facilities', label: 'Facilities Catalog' },
        { id: 'my_bookings', label: 'Active Bookings' },
        { id: 'cpp_code', label: 'C++ Core Engine' },
      ];
    }
    // Admin
    return [
      { id: 'facilities', label: 'Campus Facilities' },
      { id: 'queues', label: 'Global Queues' },
      { id: 'predictions', label: 'Prediction Diagnostics' },
      { id: 'allocator', label: 'Resource Scheduler' },
      { id: 'analytics', label: 'Global Analytics' },
      { id: 'users', label: 'User & Role RBAC' },
      { id: 'simulation', label: 'Simulation Suite' },
      { id: 'cpp_code', label: 'C++ Architecture' },
    ];
  };

  const navItems = getNavItems();

  const getRoleBadge = (role: UserRole) => {
    const norm = normalizeRole(role);
    if (norm === 'admin') {
      return {
        label: 'Admin',
        bg: 'bg-purple-100 text-purple-800 border-purple-200',
      };
    }
    if (norm === 'faculty') {
      return {
        label: 'Faculty',
        bg: 'bg-indigo-100 text-indigo-800 border-indigo-200',
      };
    }
    return {
      label: 'Student',
      bg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    };
  };

  const activeRoleBadge = getRoleBadge(currentUser.role);

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-2xs">
      {/* Emergency Rerouting Alert Banner */}
      {emergencyActive && (
        <div className="bg-rose-600 text-white text-xs px-4 py-1.5 flex items-center justify-between font-medium">
          <div className="flex items-center gap-2 max-w-7xl mx-auto w-full">
            <Flame className="w-3.5 h-3.5 shrink-0 animate-pulse text-amber-300" />
            <span>
              <strong>CAMPUS CONGESTION ALERT:</strong> High footfall detected. Queue diversion in effect. Check alternate facility wings.
            </span>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-6">
          {/* Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => onSelectTab(navItems[0].id)}
              className="flex items-center gap-2.5 text-left focus:outline-none"
            >
              <div className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center font-bold text-sm tracking-wider">
                CF
              </div>
              <span className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
                CampusFlow
              </span>
            </button>
            <span className="hidden sm:inline-block text-slate-300">/</span>
            <div className="hidden sm:flex items-center gap-1.5">
              <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${activeRoleBadge.bg}`}>
                {activeRoleBadge.label} Session
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                Firestore Connected
              </span>
            </div>
          </div>

          {/* Role-Specific Navigation Links */}
          <nav className="hidden lg:flex items-center gap-3 xl:gap-5 overflow-x-auto [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`text-xs font-medium whitespace-nowrap py-1 transition-colors relative ${
                    isActive
                      ? 'text-slate-900 font-semibold border-b-2 border-slate-900'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* User Persona Switcher & Google Auth */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Google Sign In / Firebase Status */}
            {!isFirebaseUser ? (
              <button
                onClick={onGoogleSignIn}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 transition-colors shadow-2xs"
                title="Sign in with your Google Workspace / Gmail account"
              >
                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Google Sign-In</span>
              </button>
            ) : (
              <button
                onClick={onSignOut}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-medium text-slate-700 transition-colors"
                title="Sign out of Google"
              >
                <LogOut className="w-3 h-3 text-slate-500" />
                <span>Sign Out</span>
              </button>
            )}

            {/* Persona Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-medium text-slate-800 transition-colors whitespace-nowrap"
              >
                {currentUser.avatarUrl ? (
                  <img
                    src={currentUser.avatarUrl}
                    alt={currentUser.name}
                    className="w-5 h-5 rounded-full object-cover"
                  />
                ) : (
                  <UserCircle className="w-4 h-4 text-slate-500" />
                )}
                <span className="truncate max-w-[110px]">{currentUser.name}</span>
                <span
                  className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded border ${activeRoleBadge.bg}`}
                >
                  {activeRoleBadge.label}
                </span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-fadeIn">
                  <div className="px-3 py-1.5 border-b border-slate-100">
                    <div className="text-[11px] font-bold text-slate-900">
                      Switch Role & Persona (Instant RBAC Testing)
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      Select a role below to preview data isolation and view privileges.
                    </div>
                  </div>

                  <div className="p-1 space-y-0.5 max-h-72 overflow-y-auto">
                    {availableUsers.map((u) => {
                      const badge = getRoleBadge(u.role);
                      const isSelected = u.id === currentUser.id;

                      return (
                        <button
                          key={u.id}
                          onClick={() => {
                            onSelectUser(u);
                            setUserDropdownOpen(false);
                          }}
                          className={`w-full text-left px-3 py-2 text-xs rounded-lg flex items-center justify-between transition-colors ${
                            isSelected
                              ? 'bg-slate-100 text-slate-900 font-semibold'
                              : 'text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          <div className="truncate mr-2">
                            <div className="font-medium text-slate-900 truncate">{u.name}</div>
                            <div className="text-[10px] text-slate-500 truncate">
                              {u.department || u.email}
                            </div>
                          </div>
                          <span
                            className={`text-[9px] font-mono font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border shrink-0 ${badge.bg}`}
                          >
                            {badge.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="mt-1 pt-1.5 border-t border-slate-100 px-3 py-1 flex items-center justify-between text-[11px]">
                    <button
                      onClick={() => {
                        onGoogleSignIn();
                        setUserDropdownOpen(false);
                      }}
                      className="text-blue-600 hover:text-blue-800 font-medium flex items-center gap-1"
                    >
                      <LogIn className="w-3 h-3" />
                      Sign in with Google
                    </button>
                    {isFirebaseUser && (
                      <button
                        onClick={() => {
                          onSignOut();
                          setUserDropdownOpen(false);
                        }}
                        className="text-slate-500 hover:text-rose-600"
                      >
                        Sign out
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Mobile menu tab selector */}
            <div className="lg:hidden flex items-center">
              <select
                value={activeTab}
                onChange={(e) => onSelectTab(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-md py-1.5 px-2 text-slate-800 focus:outline-none"
              >
                {navItems.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
