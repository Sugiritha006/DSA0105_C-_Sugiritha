#include "PredictionEngine.hpp"
#include <stdexcept>
#include <numeric>
#include <iomanip>
#include <sstream>

namespace campusflow {

std::string congestionLevelToString(CongestionLevel level) {
    switch (level) {
        case CongestionLevel::Low: return "Low";
        case CongestionLevel::Moderate: return "Moderate";
        case CongestionLevel::High: return "High";
        case CongestionLevel::Critical: return "Critical";
        default: return "Unknown";
    }
}

PredictionEngine::PredictionEngine(CongestionThresholds thresholds, double alpha)
    : thresholds_(thresholds), congestionCorrectionAlpha_(alpha) {}

double PredictionEngine::calculateBaselineWait(int peopleAhead, double avgServiceTime, int activeCounters) const {
    if (activeCounters <= 0) {
        // If counters are 0, service cannot proceed
        return -1.0; 
    }
    if (peopleAhead <= 0) {
        return 0.0;
    }
    return (static_cast<double>(peopleAhead) * avgServiceTime) / static_cast<double>(activeCounters);
}

CongestionLevel PredictionEngine::classifyCongestion(double demand, double capacity) const {
    if (capacity <= 0.0) return CongestionLevel::Critical;
    double ratio = demand / capacity;
    if (ratio <= thresholds_.lowMax) return CongestionLevel::Low;
    if (ratio <= thresholds_.moderateMax) return CongestionLevel::Moderate;
    if (ratio <= thresholds_.highMax) return CongestionLevel::High;
    return CongestionLevel::Critical;
}

PredictionResult PredictionEngine::predictWaitTime(int peopleAhead, double avgServiceTime, int activeCounters,
                                                   int facilityCapacity, double historicalDemand,
                                                   bool isOperational) const {
    PredictionResult result;
    result.historicalDemandRate = historicalDemand;

    // Get current ISO-like timestamp string
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);
    std::stringstream ss;
    ss << std::put_time(std::gmtime(&in_time_t), "%Y-%m-%d %H:%M:%SZ");
    result.timestamp = ss.str();

    if (!isOperational || activeCounters <= 0) {
        result.estimatedWaitMinutes = -1.0;
        result.baselineWaitMinutes = -1.0;
        result.confidenceLower = 0.0;
        result.confidenceUpper = 0.0;
        result.congestion = CongestionLevel::Critical;
        result.congestionRatio = 1.0;
        result.formulaExplanation = "Facility is currently non-operational or has 0 active service counters.";
        return result;
    }

    double baseline = calculateBaselineWait(peopleAhead, avgServiceTime, activeCounters);
    result.baselineWaitMinutes = baseline;

    double ratio = (facilityCapacity > 0) ? (historicalDemand / static_cast<double>(facilityCapacity)) : 1.0;
    result.congestionRatio = ratio;
    result.congestion = classifyCongestion(historicalDemand, static_cast<double>(facilityCapacity));

    // Refinement factor based on historical load pressure
    // T_adjusted = T_baseline * (1.0 + alpha * (demand / capacity))
    double factor = 1.0 + (congestionCorrectionAlpha_ * ratio);
    double adjusted = baseline * factor;
    result.estimatedWaitMinutes = adjusted;

    // Uncertainty interval based on standard variance in service time (e.g. +/- 15% plus base delta)
    double delta = std::max(1.0, adjusted * 0.15);
    result.confidenceLower = std::max(0.0, adjusted - delta);
    result.confidenceUpper = adjusted + delta;

    std::ostringstream expl;
    expl << "T_est = (" << peopleAhead << " ahead * " << avgServiceTime << "m) / "
         << activeCounters << " counters * [1 + " << congestionCorrectionAlpha_ << " * ("
         << historicalDemand << " / " << facilityCapacity << ")] = "
         << std::fixed << std::setprecision(1) << adjusted << " mins";
    result.formulaExplanation = expl.str();

    return result;
}

double PredictionEngine::forecastDemandMovingAverage(const std::vector<double>& historicalCounts,
                                                     const std::vector<double>& weights) const {
    if (historicalCounts.empty()) return 0.0;

    if (weights.empty() || weights.size() != historicalCounts.size()) {
        // Standard Simple Moving Average
        double sum = std::accumulate(historicalCounts.begin(), historicalCounts.end(), 0.0);
        return sum / static_cast<double>(historicalCounts.size());
    }

    // Weighted Moving Average
    double weightedSum = 0.0;
    double weightTotal = 0.0;
    for (size_t i = 0; i < historicalCounts.size(); ++i) {
        weightedSum += historicalCounts[i] * weights[i];
        weightTotal += weights[i];
    }
    return (weightTotal > 0.0) ? (weightedSum / weightTotal) : 0.0;
}

double PredictionEngine::evaluateMAE(const std::vector<DatasetPoint>& testData, double capacity) const {
    if (testData.empty()) return 0.0;

    double totalAbsoluteError = 0.0;
    for (const auto& dp : testData) {
        PredictionResult pred = predictWaitTime(dp.peopleAhead, dp.avgServiceTime,
                                                dp.activeCounters, static_cast<int>(capacity),
                                                dp.historicalDemandRate, true);
        double err = std::abs(pred.estimatedWaitMinutes - dp.actualObservedWaitMinutes);
        totalAbsoluteError += err;
    }
    return totalAbsoluteError / static_cast<double>(testData.size());
}

} // namespace campusflow
