export type UserRole = 'student' | 'faculty' | 'admin' | 'facility_manager';

export function normalizeRole(role: UserRole): 'student' | 'faculty' | 'admin' {
  if (role === 'facility_manager') return 'faculty';
  return role;
}

export interface User {
  id: number;
  uid?: string;
  username: string;
  email: string;
  role: UserRole;
  studentIdNumber?: string;
  department?: string;
  name: string;
  avatarUrl?: string;
}

export type FacilityCategory =
  | 'Computing Lab'
  | 'Study Lounge'
  | 'Maker Space'
  | 'Quiet Study'
  | 'Student Services'
  | 'Canteen';

export interface OperatingHours {
  openHour: number;  // e.g. 8 (08:00)
  closeHour: number; // e.g. 22 (22:00)
}

export interface ServiceCounter {
  id: number;
  facilityId: number;
  counterNumber: number;
  counterName: string;
  isActive: boolean;
  currentServingTicket?: string;
  staffName?: string;
  isPaused?: boolean;
}

export interface Facility {
  id: number;
  name: string;
  category: FacilityCategory;
  building: string;
  roomNumber: string;
  capacity: number;
  activeCounters: number;
  totalCounters: number;
  hours: OperatingHours;
  isOperational: boolean;
  avgServiceTimeMinutes: number;
  imageUrl?: string;
  description: string;
  department?: string;
  equipment?: string[];
  services?: string[];
  guidelines?: string[];
}

export type BookingStatus = 'confirmed' | 'completed' | 'cancelled';

export interface Booking {
  id: string; // e.g. "BK-2026-101"
  userId: number;
  userUid?: string;
  userName: string;
  facilityId: number;
  facilityName: string;
  date: string; // YYYY-MM-DD
  startHour: number; // e.g. 10
  endHour: number;   // e.g. 12
  attendeesCount: number;
  status: BookingStatus;
  notes?: string;
  createdAt: string;
}

export type QueueStatus = 'waiting' | 'serving' | 'completed' | 'cancelled';

export interface QueueTicket {
  id: string; // e.g. "QF-101"
  facilityId: number;
  facilityName: string;
  userId: number;
  userUid?: string;
  studentName: string;
  priorityLevel: number; // 0 = standard FIFO, 1 = priority
  status: QueueStatus;
  assignedCounter?: number;
  estimatedWaitMinutes: number;
  joinedAt: string;
  startedAt?: string;
  completedAt?: string;
}

export type CongestionLevel = 'Low' | 'Moderate' | 'High' | 'Critical';

export interface PredictionResult {
  estimatedWaitMinutes: number;
  baselineWaitMinutes: number;
  confidenceLower: number;
  confidenceUpper: number;
  congestion: CongestionLevel;
  congestionRatio: number;
  timestamp: string;
  historicalDemandRate: number;
  formulaExplanation: string;
}

export interface SchedulerWeights {
  availabilityWeight: number; // default 0.35
  waitTimeWeight: number;     // default 0.25
  demandWeight: number;       // default 0.20
  utilizationWeight: number;  // default 0.20
}

export interface SlotCandidate {
  facilityId: number;
  facilityName: string;
  category: FacilityCategory;
  startHour: number;
  endHour: number;
  date: string;
  availableCapacity: number;
  totalCapacity: number;
  predictedWaitMinutes: number;
  expectedDemand: number;
  utilizationRate: number;
  score: number;
  isFeasible: boolean;
  reason: string;
}

export interface AllocationRecommendation {
  rankedCandidates: SlotCandidate[];
  preferredSlotEvaluation?: SlotCandidate;
  preferredSlotFeasible: boolean;
  alternativeRecommendations: SlotCandidate[];
  algorithmUsed: 'WeightedMultiFactor' | 'GreedyBaseline';
  comparisonNotes: string;
}

export interface SimulationScenario {
  id: number;
  name: string;
  description: string;
  category: 'Queue' | 'Concurrency' | 'Capacity' | 'Prediction' | 'Scheduling';
  status: 'idle' | 'running' | 'passed' | 'failed';
  executionTimeMs?: number;
  logs: string[];
  assertions: { check: string; passed: boolean }[];
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: number;
  userName: string;
  actionType: string;
  entityName: string;
  entityId: string;
  details: string;
}

export interface BenchmarkPoint {
  id: number;
  peopleAhead: number;
  avgServiceTime: number;
  activeCounters: number;
  historicalDemandRate: number;
  actualObservedWaitMinutes: number;
  predictedWaitMinutes: number;
  absoluteError: number;
}

export interface SystemConfig {
  alphaSensitivity: number; // default 0.15
  criticalCongestionThreshold: number; // default 0.90
  highCongestionThreshold: number; // default 0.70
  emergencyRerouteActive: boolean;
  emergencyMessage?: string;
  lastUpdated: string;
}

export interface RBACPermissions {
  canManageAllQueues: boolean;
  canManageDepartmentQueues: boolean;
  canCallNextQueue: boolean;
  canPauseResumeQueue: boolean;
  canOverrideBooking: boolean;
  canEditFacilities: boolean;
  canAccessFullPredictionEngine: boolean;
  canAccessDepartmentPrediction: boolean;
  canAccessRawAnalytics: boolean;
  canTuneHyperparameters: boolean;
  canManageUsers: boolean;
  canViewAuditLogs: boolean;
  canTriggerEmergencyReroute: boolean;
}

export function getRolePermissions(role: UserRole): RBACPermissions {
  const norm = normalizeRole(role);
  if (norm === 'admin') {
    return {
      canManageAllQueues: true,
      canManageDepartmentQueues: true,
      canCallNextQueue: true,
      canPauseResumeQueue: true,
      canOverrideBooking: true,
      canEditFacilities: true,
      canAccessFullPredictionEngine: true,
      canAccessDepartmentPrediction: true,
      canAccessRawAnalytics: true,
      canTuneHyperparameters: true,
      canManageUsers: true,
      canViewAuditLogs: true,
      canTriggerEmergencyReroute: true,
    };
  }
  if (norm === 'faculty') {
    return {
      canManageAllQueues: false,
      canManageDepartmentQueues: true,
      canCallNextQueue: true,
      canPauseResumeQueue: true,
      canOverrideBooking: true,
      canEditFacilities: false,
      canAccessFullPredictionEngine: false,
      canAccessDepartmentPrediction: true,
      canAccessRawAnalytics: false,
      canTuneHyperparameters: false,
      canManageUsers: false,
      canViewAuditLogs: false,
      canTriggerEmergencyReroute: false,
    };
  }
  // Student
  return {
    canManageAllQueues: false,
    canManageDepartmentQueues: false,
    canCallNextQueue: false,
    canPauseResumeQueue: false,
    canOverrideBooking: false,
    canEditFacilities: false,
    canAccessFullPredictionEngine: false,
    canAccessDepartmentPrediction: false,
    canAccessRawAnalytics: false,
    canTuneHyperparameters: false,
    canManageUsers: false,
    canViewAuditLogs: false,
    canTriggerEmergencyReroute: false,
  };
}
