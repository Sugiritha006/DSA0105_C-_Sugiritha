-- =====================================================================
-- CampusFlow: Intelligent Campus Queue & Resource Allocation System
-- Target Database: MySQL 8.x (InnoDB Engine, utf8mb4)
-- =====================================================================

DROP DATABASE IF EXISTS campusflow;
CREATE DATABASE campusflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campusflow;

-- 1. Users Table (Role-based access control, secure hash storage)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) NOT NULL UNIQUE,
    email VARCHAR(128) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('student', 'facility_manager', 'admin') NOT NULL DEFAULT 'student',
    student_id_number VARCHAR(32) NULL,
    department VARCHAR(128) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_role (role),
    INDEX idx_user_email (email)
) ENGINE=InnoDB;

-- 2. Facilities Table
CREATE TABLE facilities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    category ENUM('Computing Lab', 'Study Lounge', 'Maker Space', 'Quiet Study', 'Student Services') NOT NULL,
    building VARCHAR(128) NOT NULL,
    room_number VARCHAR(32) NOT NULL,
    capacity INT NOT NULL CHECK (capacity > 0),
    active_counters INT NOT NULL DEFAULT 1 CHECK (active_counters >= 0),
    is_operational BOOLEAN NOT NULL DEFAULT TRUE,
    avg_service_time_minutes DECIMAL(5,2) NOT NULL DEFAULT 5.00 CHECK (avg_service_time_minutes > 0),
    image_url VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_facility_category (category),
    INDEX idx_facility_operational (is_operational)
) ENGINE=InnoDB;

-- 3. Facility Operating Hours Table
CREATE TABLE facility_operating_hours (
    id INT AUTO_INCREMENT PRIMARY KEY,
    facility_id INT NOT NULL,
    day_of_week TINYINT NOT NULL CHECK (day_of_week BETWEEN 0 AND 6), -- 0=Sunday, 6=Saturday
    open_time TIME NOT NULL,
    close_time TIME NOT NULL,
    FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
    UNIQUE KEY uk_facility_day (facility_id, day_of_week)
) ENGINE=InnoDB;

-- 4. Facility Specific Resources (e.g. GPU Workstations, 3D Printers)
CREATE TABLE facility_resources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    facility_id INT NOT NULL,
    resource_name VARCHAR(128) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    status ENUM('available', 'maintenance', 'reserved') NOT NULL DEFAULT 'available',
    FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
    INDEX idx_resource_facility (facility_id)
) ENGINE=InnoDB;

-- 5. Service Counters (Individual desks/counters within a facility)
CREATE TABLE service_counters (
    id INT AUTO_INCREMENT PRIMARY KEY,
    facility_id INT NOT NULL,
    counter_number INT NOT NULL,
    counter_name VARCHAR(64) NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    current_serving_queue_id VARCHAR(32) NULL,
    FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
    UNIQUE KEY uk_facility_counter (facility_id, counter_number)
) ENGINE=InnoDB;

-- 6. Bookings Table (Enforces non-overlapping, concurrency checks via constraints)
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_reference VARCHAR(32) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    facility_id INT NOT NULL,
    booking_date DATE NOT NULL,
    start_hour INT NOT NULL CHECK (start_hour BETWEEN 0 AND 23),
    end_hour INT NOT NULL CHECK (end_hour BETWEEN 1 AND 24 AND end_hour > start_hour),
    attendees_count INT NOT NULL DEFAULT 1 CHECK (attendees_count > 0),
    status ENUM('confirmed', 'completed', 'cancelled') NOT NULL DEFAULT 'confirmed',
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
    INDEX idx_booking_schedule (facility_id, booking_date, start_hour, end_hour),
    INDEX idx_booking_user (user_id, status)
) ENGINE=InnoDB;

-- 7. Queue Entries Table (FIFO queue tracking with optional priority level)
CREATE TABLE queue_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    queue_ticket_id VARCHAR(32) NOT NULL UNIQUE,
    facility_id INT NOT NULL,
    user_id INT NOT NULL,
    student_name VARCHAR(128) NOT NULL,
    priority_level INT NOT NULL DEFAULT 0,
    status ENUM('waiting', 'serving', 'completed', 'cancelled') NOT NULL DEFAULT 'waiting',
    assigned_counter_id INT NULL,
    estimated_wait_minutes DECIMAL(5,1) NOT NULL DEFAULT 0.0,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    service_started_at TIMESTAMP NULL,
    service_completed_at TIMESTAMP NULL,
    FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_counter_id) REFERENCES service_counters(id) ON DELETE SET NULL,
    INDEX idx_queue_active (facility_id, status, joined_at)
) ENGINE=InnoDB;

-- 8. Service History (Measured empirical service records for model grounding)
CREATE TABLE service_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    facility_id INT NOT NULL,
    counter_id INT NULL,
    queue_ticket_id VARCHAR(32) NOT NULL,
    service_duration_minutes DECIMAL(5,2) NOT NULL,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
    INDEX idx_service_history_fac (facility_id, completed_at)
) ENGINE=InnoDB;

-- 9. Demand History (Aggregated counts grouped by facility and time slot)
CREATE TABLE demand_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    facility_id INT NOT NULL,
    date_recorded DATE NOT NULL,
    time_slot_hour INT NOT NULL CHECK (time_slot_hour BETWEEN 0 AND 23),
    total_arrivals INT NOT NULL DEFAULT 0,
    peak_queue_length INT NOT NULL DEFAULT 0,
    avg_observed_wait_minutes DECIMAL(5,2) NOT NULL DEFAULT 0.0,
    FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
    UNIQUE KEY uk_facility_demand_slot (facility_id, date_recorded, time_slot_hour)
) ENGINE=InnoDB;

-- 10. Prediction Records (Audit of algorithm predictions vs actuals)
CREATE TABLE prediction_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    facility_id INT NOT NULL,
    predicted_wait_minutes DECIMAL(5,2) NOT NULL,
    actual_wait_minutes DECIMAL(5,2) NULL,
    absolute_error_minutes DECIMAL(5,2) NULL,
    congestion_level ENUM('Low', 'Moderate', 'High', 'Critical') NOT NULL,
    active_counters_at_prediction INT NOT NULL,
    people_ahead_at_prediction INT NOT NULL,
    predicted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
    INDEX idx_pred_mae (facility_id, predicted_at)
) ENGINE=InnoDB;

-- 11. Allocation Recommendations (Log of scheduler optimization proposals)
CREATE TABLE allocation_recommendations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    requested_facility_id INT NOT NULL,
    requested_start_hour INT NOT NULL,
    requested_end_hour INT NOT NULL,
    was_preferred_feasible BOOLEAN NOT NULL,
    recommended_facility_id INT NOT NULL,
    recommended_start_hour INT NOT NULL,
    recommended_end_hour INT NOT NULL,
    weighted_score DECIMAL(5,3) NOT NULL,
    selection_rationale TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (requested_facility_id) REFERENCES facilities(id) ON DELETE CASCADE,
    FOREIGN KEY (recommended_facility_id) REFERENCES facilities(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 12. Audit Logs Table (System transparency and security logging)
CREATE TABLE audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action_type VARCHAR(64) NOT NULL,
    entity_name VARCHAR(64) NOT NULL,
    entity_id VARCHAR(64) NOT NULL,
    details TEXT NOT NULL,
    ip_address VARCHAR(45) DEFAULT '127.0.0.1',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_created (created_at),
    INDEX idx_audit_action (action_type)
) ENGINE=InnoDB;
