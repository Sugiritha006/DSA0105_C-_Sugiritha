#pragma once

#include "User.hpp"
#include <string>
#include <vector>
#include <memory>
#include <unordered_map>
#include <mutex>
#include <optional>

namespace campusflow {

struct AuthToken {
    std::string token;
    int userId;
    UserRole role;
    std::string expiresAt;
};

class AuthenticationManager {
private:
    std::vector<std::shared_ptr<User>> users_;
    std::unordered_map<std::string, AuthToken> activeSessions_;
    mutable std::mutex authMutex_;

    // Cryptographic hashing helper (SHA-256 with salt)
    static std::string hashPasswordWithSalt(const std::string& password, const std::string& salt);

public:
    AuthenticationManager();

    // Register user with secure password hash
    std::shared_ptr<User> registerUser(const std::string& username, const std::string& email,
                                       const std::string& rawPassword, UserRole role,
                                       const std::string& extraField1 = "",
                                       const std::string& extraField2 = "");

    // Authenticate and issue session token
    std::optional<AuthToken> login(const std::string& usernameOrEmail, const std::string& rawPassword);

    // Validate active session token and verify role permission
    std::optional<AuthToken> validateToken(const std::string& token) const;
    bool hasPermission(const std::string& token, UserRole requiredRole) const;

    void revokeToken(const std::string& token);
    std::shared_ptr<User> getUserById(int userId) const;
    const std::vector<std::shared_ptr<User>>& getAllUsers() const { return users_; }
};

} // namespace campusflow
