cmake_minimum_required(VERSION 3.16)
project(CampusFlow VERSION 1.0.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# Compiler warnings and optimization flags
if(MSVC)
    add_compile_options(/W4 /EHsc /O2)
else()
    add_compile_options(-Wall -Wextra -Wpedantic -O2)
endif()

# Include directories
include_directories(
    ${CMAKE_CURRENT_SOURCE_DIR}/include
)

# Core Library Sources
set(CORE_SOURCES
    src/User.cpp
    src/Facility.cpp
    src/Booking.cpp
    src/QueueManager.cpp
    src/PredictionEngine.cpp
    src/ResourceScheduler.cpp
    src/AuthenticationManager.cpp
)

# Static library for core algorithms
add_library(campusflow_core STATIC ${CORE_SOURCES})

# REST API Server Executable
add_executable(campusflow_server
    src/main.cpp
)
target_link_libraries(campusflow_server PRIVATE campusflow_core)

# Unit and Integration Test Executable (10 Scenarios & MAE Benchmark)
add_executable(test_scenarios
    tests/test_scenarios.cpp
)
target_link_libraries(test_scenarios PRIVATE campusflow_core)

enable_testing()
add_test(NAME AllAcceptanceScenarios COMMAND test_scenarios)
