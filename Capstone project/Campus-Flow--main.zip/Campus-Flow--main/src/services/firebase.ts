import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  onSnapshot,
  getDocFromServer,
  Firestore,
} from 'firebase/firestore';
import { User, Facility, Booking, QueueTicket, ServiceCounter, AuditLog } from '../types/campus';
import configData from '../../firebase-applet-config.json';

const firebaseConfig = {
  apiKey: configData.apiKey,
  authDomain: configData.authDomain,
  projectId: configData.projectId,
  storageBucket: configData.storageBucket,
  messagingSenderId: configData.messagingSenderId,
  appId: configData.appId,
  firestoreDatabaseId: configData.firestoreDatabaseId,
};

// Initialize Firebase App
export const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Auth
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Initialize Firestore with specific database ID if provided
export const db: Firestore = configData.firestoreDatabaseId && configData.firestoreDatabaseId !== '(default)'
  ? getFirestore(app, configData.firestoreDatabaseId)
  : getFirestore(app);

// Connection test on boot per Firebase skill guidelines
async function testFirestoreConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline or initializing. Operating with optimistic state cache.');
    }
  }
}
testFirestoreConnection();

/**
 * Sign in with Google Popup
 */
export async function signInWithGoogle(): Promise<FirebaseUser | null> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (err: any) {
    console.error('Google sign-in error:', err);
    throw err;
  }
}

/**
 * Sign out current Firebase user
 */
export async function signOutUser(): Promise<void> {
  try {
    await signOut(auth);
  } catch (err) {
    console.error('Sign out error:', err);
  }
}

/**
 * User Profile Firestore Management
 */
export async function syncUserProfile(user: User): Promise<void> {
  try {
    const docId = user.uid || `user-${user.id}`;
    const userRef = doc(db, 'users', docId);
    await setDoc(userRef, {
      id: user.id,
      uid: docId,
      username: user.username,
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department || '',
      studentIdNumber: user.studentIdNumber || '',
      avatarUrl: user.avatarUrl || '',
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  } catch (err) {
    console.warn('Firestore user profile sync error (cached locally):', err);
  }
}

export async function getUserProfile(uid: string): Promise<User | null> {
  try {
    const userRef = doc(db, 'users', uid);
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      return snap.data() as User;
    }
  } catch (err) {
    console.warn('Error getting user profile from Firestore:', err);
  }
  return null;
}

/**
 * Firestore Sync Helpers for Real-time Persistence
 */
export async function persistBooking(booking: Booking): Promise<void> {
  try {
    const bookingRef = doc(db, 'bookings', booking.id);
    await setDoc(bookingRef, {
      ...booking,
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  } catch (err) {
    console.warn('Firestore booking persist error (cached locally):', err);
  }
}

export async function updateBookingStatusInFirestore(bookingId: string, status: string): Promise<void> {
  try {
    const bookingRef = doc(db, 'bookings', bookingId);
    await updateDoc(bookingRef, {
      status,
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.warn('Firestore booking status update error:', err);
  }
}

export async function persistQueueTicket(ticket: QueueTicket): Promise<void> {
  try {
    const ticketRef = doc(db, 'queues', ticket.id);
    await setDoc(ticketRef, {
      ...ticket,
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  } catch (err) {
    console.warn('Firestore queue ticket persist error (cached locally):', err);
  }
}

export async function updateQueueTicketInFirestore(ticketId: string, updates: Partial<QueueTicket>): Promise<void> {
  try {
    const ticketRef = doc(db, 'queues', ticketId);
    await updateDoc(ticketRef, {
      ...updates,
      updatedAt: new Date().toISOString(),
    });
  } catch (err) {
    console.warn('Firestore queue ticket update error:', err);
  }
}

export async function persistAuditLog(log: AuditLog): Promise<void> {
  try {
    const logRef = doc(db, 'auditLogs', log.id);
    await setDoc(logRef, log, { merge: true });
  } catch (err) {
    console.warn('Firestore audit log persist error (cached locally):', err);
  }
}

export async function persistFacility(facility: Facility): Promise<void> {
  try {
    const facRef = doc(db, 'facilities', `facility-${facility.id}`);
    await setDoc(facRef, facility, { merge: true });
  } catch (err) {
    console.warn('Firestore facility persist error (cached locally):', err);
  }
}

export async function persistCounter(counter: ServiceCounter): Promise<void> {
  try {
    const counterRef = doc(db, 'serviceCounters', `counter-${counter.id}`);
    await setDoc(counterRef, counter, { merge: true });
  } catch (err) {
    console.warn('Firestore counter persist error (cached locally):', err);
  }
}
