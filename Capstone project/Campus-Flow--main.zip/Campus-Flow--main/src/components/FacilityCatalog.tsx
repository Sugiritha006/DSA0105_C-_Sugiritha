import React, { useState } from 'react';
import { Facility, Booking, User, FacilityCategory } from '../types/campus';
import {
  Search,
  Filter,
  Users,
  Clock,
  Layers,
  MapPin,
  Calendar,
  AlertCircle,
  Plus,
  Trash2,
  CheckCircle,
  BookOpen,
  Info,
  X,
  Shield,
  Wrench,
} from 'lucide-react';

interface FacilityCatalogProps {
  facilities: Facility[];
  bookings: Booking[];
  currentUser: User;
  onOpenBookingModal: (facility: Facility) => void;
  onJoinQueue: (facility: Facility) => void;
  onCancelBooking: (bookingId: string) => void;
  onUpdateFacility?: (facility: Facility) => void;
  onAddNewFacility?: (newFacility: Omit<Facility, 'id'>) => void;
}

export const FacilityCatalog: React.FC<FacilityCatalogProps> = ({
  facilities,
  bookings,
  currentUser,
  onOpenBookingModal,
  onJoinQueue,
  onCancelBooking,
  onAddNewFacility,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [onlyOperational, setOnlyOperational] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedCatalogFacility, setSelectedCatalogFacility] = useState<Facility | null>(null);
  const [imageErrors, setImageErrors] = useState<Record<number, boolean>>({});

  // New facility form state
  const [newFacName, setNewFacName] = useState('');
  const [newFacCategory, setNewFacCategory] = useState<FacilityCategory>('Computing Lab');
  const [newFacBuilding, setNewFacBuilding] = useState('');
  const [newFacRoom, setNewFacRoom] = useState('');
  const [newFacCapacity, setNewFacCapacity] = useState(30);
  const [newFacCounters, setNewFacCounters] = useState(2);
  const [newFacOpen, setNewFacOpen] = useState(8);
  const [newFacClose, setNewFacClose] = useState(22);
  const [newFacServiceTime, setNewFacServiceTime] = useState(5.0);

  const categories = [
    'All',
    'Computing Lab',
    'Study Lounge',
    'Maker Space',
    'Quiet Study',
    'Student Services',
  ];

  const filteredFacilities = facilities.filter((f) => {
    const matchesSearch =
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.building.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.roomNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory =
      selectedCategory === 'All' || f.category === selectedCategory;
    const matchesOperational = !onlyOperational || f.isOperational;
    return matchesSearch && matchesCategory && matchesOperational;
  });

  const userBookings = bookings.filter((b) => b.userId === currentUser.id);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onAddNewFacility) {
      onAddNewFacility({
        name: newFacName,
        category: newFacCategory,
        building: newFacBuilding,
        roomNumber: newFacRoom,
        capacity: newFacCapacity,
        activeCounters: newFacCounters,
        totalCounters: newFacCounters,
        hours: { openHour: newFacOpen, closeHour: newFacClose },
        isOperational: true,
        avgServiceTimeMinutes: newFacServiceTime,
        description: 'New campus facility managed via administrator console.',
      });
      setShowAddModal(false);
      setNewFacName('');
      setNewFacBuilding('');
      setNewFacRoom('');
    }
  };

  return (
    <div className="space-y-8">
      {/* Page Title & Search Bar */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Campus Facilities & Booking Catalog
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Discover real-time laboratory, study space, and advising counter availability across campus.
          </p>
        </div>

        {currentUser.role !== 'student' && onAddNewFacility && (
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            Add Facility
          </button>
        )}
      </div>

      {/* Filter and Search Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Category Filter Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="flex items-center gap-3">
          <div className="relative min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by name or building..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs bg-white border border-slate-200 rounded-lg pl-8 pr-3 py-1.5 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
          </div>

          <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer select-none whitespace-nowrap">
            <input
              type="checkbox"
              checked={onlyOperational}
              onChange={(e) => setOnlyOperational(e.target.checked)}
              className="rounded border-slate-300 text-slate-900 focus:ring-slate-900 w-3.5 h-3.5"
            />
            <span>Operational Only</span>
          </label>
        </div>
      </div>

      {/* Facility Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredFacilities.map((facility) => {
          return (
            <div
              key={facility.id}
              className="bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col justify-between hover:border-slate-300 transition-colors group"
            >
              <div>
                {/* Image Asset or Minimal Styled Header */}
                <div
                  onClick={() => setSelectedCatalogFacility(facility)}
                  className="h-44 bg-slate-100 relative overflow-hidden cursor-pointer"
                  title="Click to view detailed facility equipment catalog and services"
                >
                  {facility.imageUrl && !imageErrors[facility.id] ? (
                    <img
                      src={facility.imageUrl}
                      alt={facility.name}
                      referrerPolicy="no-referrer"
                      onError={() =>
                        setImageErrors((prev) => ({ ...prev, [facility.id]: true }))
                      }
                      className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center bg-slate-900 text-white p-4 text-center">
                      <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center mb-1.5 text-slate-300">
                        <Layers className="w-4 h-4" />
                      </div>
                      <span className="text-xs font-semibold text-slate-200 line-clamp-1">{facility.name}</span>
                      <span className="text-[10px] text-slate-400 mt-0.5">{facility.category} · {facility.building}</span>
                    </div>
                  )}

                  <div className="absolute top-2.5 right-2.5">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-md ${
                        facility.isOperational
                          ? 'bg-emerald-900/80 text-emerald-100 backdrop-blur-sm'
                          : 'bg-rose-900/80 text-rose-100 backdrop-blur-sm'
                      }`}
                    >
                      {facility.isOperational ? 'Operational' : 'Maintenance'}
                    </span>
                  </div>

                  <div className="absolute bottom-2 left-2.5 right-2.5 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="text-[10px] font-medium text-white bg-slate-900/80 backdrop-blur-sm px-2 py-0.5 rounded flex items-center gap-1">
                      <BookOpen className="w-3 h-3" />
                      View Facility Catalog
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <div className="flex items-center gap-1.5">
                      <span>{facility.category}</span>
                      <span aria-hidden="true">·</span>
                      <span>{facility.building}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">{facility.roomNumber}</span>
                    </div>
                    <button
                      onClick={() => setSelectedCatalogFacility(facility)}
                      className="text-[11px] font-medium text-slate-700 hover:text-slate-900 underline flex items-center gap-0.5 shrink-0"
                    >
                      <BookOpen className="w-3 h-3" />
                      Catalog Specs
                    </button>
                  </div>

                  <h3
                    onClick={() => setSelectedCatalogFacility(facility)}
                    className="text-base font-semibold text-slate-900 mt-1 line-clamp-1 cursor-pointer hover:text-slate-700 transition-colors"
                  >
                    {facility.name}
                  </h3>

                  <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed">
                    {facility.description}
                  </p>

                  {/* Metadata Specs (Strict Zero-Pill Unboxed Text) */}
                  <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs text-slate-600">
                    <div className="flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Capacity:</span>
                      <span className="font-mono tabular-nums font-semibold text-slate-800">
                        {facility.capacity} seats
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Counters:</span>
                      <span className="font-mono tabular-nums font-semibold text-slate-800">
                        {facility.activeCounters} active
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Hours:</span>
                      <span className="font-mono tabular-nums text-slate-800">
                        {facility.hours.openHour.toString().padStart(2, '0')}:00 -{' '}
                        {facility.hours.closeHour.toString().padStart(2, '0')}:00
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Avg Service:</span>
                      <span className="font-mono tabular-nums text-slate-800">
                        {facility.avgServiceTimeMinutes.toFixed(1)}m
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center gap-2">
                <button
                  onClick={() => onOpenBookingModal(facility)}
                  disabled={!facility.isOperational}
                  className="flex-1 py-1.5 px-2.5 text-xs font-medium text-slate-900 bg-white border border-slate-200 rounded-lg hover:bg-slate-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-center whitespace-nowrap"
                >
                  Reserve Slot
                </button>

                <button
                  onClick={() => setSelectedCatalogFacility(facility)}
                  className="py-1.5 px-2.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors text-center whitespace-nowrap flex items-center gap-1"
                  title="View full inventory and service catalog"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Catalog</span>
                </button>

                <button
                  onClick={() => onJoinQueue(facility)}
                  disabled={!facility.isOperational || facility.activeCounters === 0}
                  className="flex-1 py-1.5 px-2.5 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-center whitespace-nowrap"
                >
                  Join Queue
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredFacilities.length === 0 && (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200 text-slate-500 text-xs">
          No campus facilities match the current query or filter criteria.
        </div>
      )}

      {/* User's Active Bookings Section */}
      <div className="pt-8 border-t border-slate-200">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Your Campus Bookings ({currentUser.name})
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Manage your confirmed reservation slots and cancel upcoming sessions to free capacity.
            </p>
          </div>
          <span className="text-xs font-mono text-slate-500">
            {userBookings.filter((b) => b.status === 'confirmed').length} Active
          </span>
        </div>

        {userBookings.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-xl border border-slate-200 text-slate-500 text-xs">
            You have no recorded bookings. Click "Reserve Slot" on any facility above to create your first reservation.
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <table className="min-w-full divide-y divide-slate-200 text-xs">
              <thead className="bg-slate-50 text-slate-600 font-medium">
                <tr>
                  <th scope="col" className="py-2.5 pl-4 pr-3 text-left">
                    Booking ID
                  </th>
                  <th scope="col" className="px-3 py-2.5 text-left">
                    Facility
                  </th>
                  <th scope="col" className="px-3 py-2.5 text-left">
                    Date & Slot
                  </th>
                  <th scope="col" className="px-3 py-2.5 text-right font-mono">
                    Attendees
                  </th>
                  <th scope="col" className="px-3 py-2.5 text-left">
                    Status
                  </th>
                  <th scope="col" className="px-3 py-2.5 text-left">
                    Notes
                  </th>
                  <th scope="col" className="py-2.5 pl-3 pr-4 text-right">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {userBookings.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-2.5 pl-4 pr-3 font-mono font-medium text-slate-900 whitespace-nowrap">
                      {b.id}
                    </td>
                    <td className="px-3 py-2.5 font-medium whitespace-nowrap">
                      {b.facilityName}
                    </td>
                    <td className="px-3 py-2.5 font-mono tabular-nums whitespace-nowrap text-slate-600">
                      {b.date} · {b.startHour.toString().padStart(2, '0')}:00 -{' '}
                      {b.endHour.toString().padStart(2, '0')}:00
                    </td>
                    <td className="px-3 py-2.5 font-mono tabular-nums text-right text-slate-700">
                      {b.attendeesCount}
                    </td>
                    <td className="px-3 py-2.5 whitespace-nowrap">
                      <span
                        className={`capitalize font-medium ${
                          b.status === 'confirmed'
                            ? 'text-emerald-700'
                            : b.status === 'completed'
                            ? 'text-slate-600'
                            : 'text-rose-600'
                        }`}
                      >
                        {b.status}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-slate-500 max-w-xs truncate">
                      {b.notes || '—'}
                    </td>
                    <td className="py-2.5 pl-3 pr-4 text-right whitespace-nowrap">
                      {b.status === 'confirmed' ? (
                        <button
                          onClick={() => onCancelBooking(b.id)}
                          className="text-xs font-medium text-rose-600 hover:text-rose-800 transition-colors"
                        >
                          Cancel Booking
                        </button>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Facility Modal (Admin/Manager) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="bg-white rounded-xl border border-slate-200 max-w-md w-full p-6 shadow-xl animate-in fade-in zoom-in-95">
            <h3 className="text-base font-semibold text-slate-900 pb-3 border-b border-slate-100">
              Create New Campus Facility
            </h3>
            <form onSubmit={handleAddSubmit} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Facility Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Bio-Informatics Cluster Lab"
                  value={newFacName}
                  onChange={(e) => setNewFacName(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 py-1.5 px-3 focus:outline-none focus:ring-1 focus:ring-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Category
                  </label>
                  <select
                    value={newFacCategory}
                    onChange={(e) => setNewFacCategory(e.target.value as FacilityCategory)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-2 focus:outline-none focus:ring-1 focus:ring-slate-900"
                  >
                    <option value="Computing Lab">Computing Lab</option>
                    <option value="Study Lounge">Study Lounge</option>
                    <option value="Maker Space">Maker Space</option>
                    <option value="Quiet Study">Quiet Study</option>
                    <option value="Student Services">Student Services</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Capacity (Seats)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={newFacCapacity}
                    onChange={(e) => setNewFacCapacity(parseInt(e.target.value) || 1)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-3 focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Building
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Science Quad"
                    value={newFacBuilding}
                    onChange={(e) => setNewFacBuilding(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-3 focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Room Number
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. SQ-104"
                    value={newFacRoom}
                    onChange={(e) => setNewFacRoom(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-3 focus:outline-none focus:ring-1 focus:ring-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Counters
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={newFacCounters}
                    onChange={(e) => setNewFacCounters(parseInt(e.target.value) || 1)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-2 focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Open (24h)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="23"
                    value={newFacOpen}
                    onChange={(e) => setNewFacOpen(parseInt(e.target.value) || 8)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-2 focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">
                    Close (24h)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="24"
                    value={newFacClose}
                    onChange={(e) => setNewFacClose(parseInt(e.target.value) || 22)}
                    className="w-full rounded-lg border border-slate-300 py-1.5 px-2 focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Avg Service Time (Minutes)
                </label>
                <input
                  type="number"
                  step="0.5"
                  min="1"
                  value={newFacServiceTime}
                  onChange={(e) => setNewFacServiceTime(parseFloat(e.target.value) || 5.0)}
                  className="w-full rounded-lg border border-slate-300 py-1.5 px-3 focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800"
                >
                  Save Facility
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Facility Catalog & Specifications Detail Modal */}
      {selectedCatalogFacility && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
          <div className="bg-white rounded-xl border border-slate-200 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl animate-in fade-in zoom-in-95">
            {/* Modal Image Header Banner */}
            <div className="h-56 bg-slate-950 relative overflow-hidden">
              {selectedCatalogFacility.imageUrl && !imageErrors[selectedCatalogFacility.id] ? (
                <img
                  src={selectedCatalogFacility.imageUrl}
                  alt={selectedCatalogFacility.name}
                  referrerPolicy="no-referrer"
                  onError={() =>
                    setImageErrors((prev) => ({ ...prev, [selectedCatalogFacility.id]: true }))
                  }
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-slate-900 text-white p-6 text-center">
                  <div className="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center mb-2.5 text-slate-300">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <span className="text-sm font-semibold text-slate-100">{selectedCatalogFacility.name}</span>
                  <span className="text-xs text-slate-400 mt-1">{selectedCatalogFacility.category} · {selectedCatalogFacility.building}</span>
                </div>
              )}
              <button
                onClick={() => setSelectedCatalogFacility(null)}
                className="absolute top-3 right-3 p-1.5 rounded-full bg-slate-900/70 hover:bg-slate-900 text-white transition-colors"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between">
                <span className="text-[11px] font-mono px-2.5 py-1 rounded bg-slate-900/80 text-white backdrop-blur-sm">
                  {selectedCatalogFacility.category} · {selectedCatalogFacility.building} · {selectedCatalogFacility.roomNumber}
                </span>
                <span
                  className={`text-[11px] font-mono px-2.5 py-1 rounded backdrop-blur-sm ${
                    selectedCatalogFacility.isOperational
                      ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-950/80 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {selectedCatalogFacility.isOperational ? 'Operational' : 'Maintenance'}
                </span>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6">
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  {selectedCatalogFacility.name}
                </h3>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {selectedCatalogFacility.description}
                </p>
              </div>

              {/* Core Facility Specifications Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 rounded-lg bg-slate-50 border border-slate-200 text-xs">
                <div>
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Seat Capacity</div>
                  <div className="mt-0.5 font-mono tabular-nums font-bold text-slate-900 text-sm">
                    {selectedCatalogFacility.capacity} Seats
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Service Stations</div>
                  <div className="mt-0.5 font-mono tabular-nums font-bold text-slate-900 text-sm">
                    {selectedCatalogFacility.activeCounters} Active Desks
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Operating Hours</div>
                  <div className="mt-0.5 font-mono tabular-nums font-medium text-slate-800">
                    {selectedCatalogFacility.hours.openHour.toString().padStart(2, '0')}:00 -{' '}
                    {selectedCatalogFacility.hours.closeHour.toString().padStart(2, '0')}:00
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 uppercase font-mono">Avg Service Rate</div>
                  <div className="mt-0.5 font-mono tabular-nums font-medium text-slate-800">
                    {selectedCatalogFacility.avgServiceTimeMinutes.toFixed(1)} min / patron
                  </div>
                </div>
              </div>

              {/* Equipment & Hardware Catalog Section */}
              <div className="space-y-2.5">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-900">
                  <Wrench className="w-3.5 h-3.5 text-slate-600" />
                  <h4>Equipment & Hardware Inventory Catalog</h4>
                </div>
                <div className="bg-white rounded-lg border border-slate-200 p-3 space-y-2 text-xs">
                  {selectedCatalogFacility.equipment && selectedCatalogFacility.equipment.length > 0 ? (
                    selectedCatalogFacility.equipment.map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-slate-700">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-slate-500 italic">
                      Standard university academic stations and dedicated workstations installed.
                    </div>
                  )}
                </div>
              </div>

              {/* Services Offered Section */}
              <div className="space-y-2.5">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-900">
                  <BookOpen className="w-3.5 h-3.5 text-slate-600" />
                  <h4>Services & Academic Workflow Catalog</h4>
                </div>
                <div className="bg-white rounded-lg border border-slate-200 p-3 space-y-2 text-xs">
                  {selectedCatalogFacility.services && selectedCatalogFacility.services.length > 0 ? (
                    selectedCatalogFacility.services.map((svc, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-slate-700">
                        <span className="w-1.5 h-1.5 rounded-full bg-slate-900 shrink-0 mt-1.5" />
                        <span>{svc}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-slate-500 italic">
                      Standard walk-in study desk and queue services available.
                    </div>
                  )}
                </div>
              </div>

              {/* Guidelines & Policies */}
              <div className="space-y-2.5">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-900">
                  <Shield className="w-3.5 h-3.5 text-slate-600" />
                  <h4>Facility Guidelines & Operating Policies</h4>
                </div>
                <div className="bg-slate-50 rounded-lg border border-slate-200 p-3 space-y-1.5 text-xs text-slate-600">
                  {selectedCatalogFacility.guidelines && selectedCatalogFacility.guidelines.length > 0 ? (
                    selectedCatalogFacility.guidelines.map((rule, idx) => (
                      <div key={idx} className="flex items-start gap-2">
                        <span className="font-mono text-slate-400">0{idx + 1}.</span>
                        <span>{rule}</span>
                      </div>
                    ))
                  ) : (
                    <div>Follow standard campus library and laboratory conduct guidelines.</div>
                  )}
                </div>
              </div>

              {/* Action Buttons in Modal Footer */}
              <div className="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setSelectedCatalogFacility(null)}
                  className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900"
                >
                  Close Catalog
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const fac = selectedCatalogFacility;
                      setSelectedCatalogFacility(null);
                      onOpenBookingModal(fac);
                    }}
                    disabled={!selectedCatalogFacility.isOperational}
                    className="px-4 py-2 text-xs font-medium text-slate-900 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 disabled:opacity-50 transition-colors whitespace-nowrap"
                  >
                    Reserve Slot
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const fac = selectedCatalogFacility;
                      setSelectedCatalogFacility(null);
                      onJoinQueue(fac);
                    }}
                    disabled={
                      !selectedCatalogFacility.isOperational ||
                      selectedCatalogFacility.activeCounters === 0
                    }
                    className="px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50 transition-colors whitespace-nowrap"
                  >
                    Join Queue
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
