# CampusFlow System Architecture & Algorithm Specifications

## 1. High-Level Architecture Overview

CampusFlow is an enterprise campus queue and resource allocation system designed to optimize facility usage, eliminate waiting queues, and guarantee zero-conflict bookings across universities.

```
+---------------------------------------------------------------------------------------+
|                                    PRESENTATION TIER                                  |
|  +------------------------+  +------------------------+  +-------------------------+  |
|  |     Student Portal     |  | Facility Manager Suite |  |  Administrator Console  |  |
|  | - Facility Discovery   |  | - Queue Counter Control|  | - Global User RBAC      |  |
|  | - 1-Click FIFO Queue   |  | - Realtime Congestion  |  | - Algorithm Thresholds  |  |
|  | - Conflict-Free Booking|  | - Operating Hours Config|  | - Audit Trail & Reports |  |
|  +------------------------+  +------------------------+  +-------------------------+  |
+-------------------------------------------|-------------------------------------------+
                                            | REST API / JSON (HTTP 8080)
+-------------------------------------------v-------------------------------------------+
|                              C++ CORE REST ENGINE (Crow / Drogon)                     |
|                                                                                       |
|  +-----------------------------+    +-----------------------------------------------+ |
|  | Module 1: Facility & Queue  |    | Module 2: Prediction Engine                   | |
|  | - User, Student, Manager    |    | - FIFO Wait Time Formulation                  | |
|  | - QueueManager (FIFO/Pri)   |    | - Historical Moving Average Forecasting       | |
|  | - Collision Prevention      |    | - Dynamic Congestion Classifier (4 levels)    | |
|  +-----------------------------+    +-----------------------------------------------+ |
|                                                                                       |
|  +-----------------------------+    +-----------------------------------------------+ |
|  | Module 3: Resource Scheduler|    | Module 4: Simulation & Benchmark Engine       | |
|  | - Weighted Scoring Model    |    | - 10 Documented Scenario Testbeds             | |
|  | - Greedy Baseline Benchmark |    | - MAE Dataset Evaluation Grounding            | |
|  | - Alternative Slot Engine   |    | - Concurrency & Collision Invariant Verifier  | |
|  +-----------------------------+    +-----------------------------------------------+ |
+-------------------------------------------|-------------------------------------------+
                                            | C++ MySQL Connector / InnoDB Transactions
+-------------------------------------------v-------------------------------------------+
|                                   DATABASE TIER (MySQL 8.x)                           |
|  - users                     - service_counters          - prediction_records         |
|  - facilities                - bookings                  - allocation_recommendations|
|  - facility_operating_hours  - queue_entries             - audit_logs                 |
|  - facility_resources        - demand_history            - service_history            |
+---------------------------------------------------------------------------------------+
```

## 2. Relational Database Entity-Relationship (ER) Diagram

```
 [USERS] 1 ────────────< [BOOKINGS] >──────────── 1 [FACILITIES]
    │ 1                       │                        │ 1
    │                         │                        │
    │ 1                       │                        ├──< [FACILITY_RESOURCES]
    └───< [QUEUE_ENTRIES] >───┘                        │
                 │                                     ├──< [SERVICE_COUNTERS]
                 │                                     │
                 v                                     ├──< [FACILITY_OPERATING_HOURS]
         [SERVICE_COUNTERS]                            │
                                                       ├──< [DEMAND_HISTORY]
                                                       │
                                                       └──< [PREDICTION_RECORDS]
```

## 3. Mathematical Formulations & Algorithm Pseudocode

### Module 2: Waiting-Time Prediction Engine
For a FIFO queue with $N_{\text{ahead}}$ individuals ahead of the student, average service time $T_{\text{avg}}$ (minutes), and $C_{\text{active}}$ actively operating service counters:

**Baseline FIFO Delay:**
$$T_{\text{baseline}} = \frac{N_{\text{ahead}} \cdot T_{\text{avg}}}{C_{\text{active}}}$$

**Historical Congestion Adjustment:**
$$T_{\text{adjusted}} = T_{\text{baseline}} \times \left(1 + \alpha \cdot \frac{\text{Demand}_{\text{hist}}}{\text{Capacity}}\right)$$
where $\alpha = 0.15$ accounts for counter context switching and variable attendee load.

**Congestion Classification:**
$$\text{Congestion Level} = \begin{cases}
\text{Low} & \text{if } \text{Demand} / \text{Capacity} \le 0.40 \\
\text{Moderate} & \text{if } 0.40 < \text{Demand} / \text{Capacity} \le 0.70 \\
\text{High} & \text{if } 0.70 < \text{Demand} / \text{Capacity} \le 0.90 \\
\text{Critical} & \text{if } \text{Demand} / \text{Capacity} > 0.90
\end{cases}$$

### Module 3: Intelligent Resource Allocation
The scheduling engine scores available candidate slots using a multi-factor normalized utility function:

$$\text{Score}(S) = w_{\text{avail}} \cdot \left(\frac{C_{\text{avail}}}{C_{\text{total}}}\right) + w_{\text{wait}} \cdot \left(1 - \frac{\min(T_{\text{wait}}, 60)}{60}\right) + w_{\text{dem}} \cdot \left(1 - \frac{\text{Demand}}{\text{Capacity}}\right) + w_{\text{util}} \cdot (1 - U)$$

Configured default weights:
- $w_{\text{avail}} = 0.35$ (Headroom priority)
- $w_{\text{wait}} = 0.25$ (Queue latency penalty)
- $w_{\text{dem}} = 0.20$ (Demand peak smoothing)
- $w_{\text{util}} = 0.20$ (Campus-wide load balancing)

When the requested time slot is unavailable or violates capacity constraints, the engine computes alternative recommendations across time and adjacent facilities, returning sorted viable options with natural language selection explanations.
