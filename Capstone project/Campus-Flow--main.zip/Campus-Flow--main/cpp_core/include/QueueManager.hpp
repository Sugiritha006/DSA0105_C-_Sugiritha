#pragma once

#include <string>
#include <vector>
#include <deque>
#include <memory>
#include <mutex>
#include <optional>
#include <chrono>

namespace campusflow {

enum class QueueStatus {
    Waiting,
    Serving,
    Completed,
    Cancelled
};

std::string queueStatusToString(QueueStatus status);
QueueStatus stringToQueueStatus(const std::string& str);

struct QueueEntry {
    std::string queueId; // e.g. "Q-101"
    int facilityId;
    int userId;
    std::string studentName;
    int priorityLevel;   // 0 = Normal FIFO, >0 = Priority (if admin enabled)
    std::chrono::system_clock::time_point joinedAt;
    QueueStatus status;
    int assignedCounter; // 0 if not yet assigned

    QueueEntry(std::string qId, int fId, int uId, std::string name, int priority = 0)
        : queueId(std::move(qId)), facilityId(fId), userId(uId),
          studentName(std::move(name)), priorityLevel(priority),
          joinedAt(std::chrono::system_clock::now()),
          status(QueueStatus::Waiting), assignedCounter(0) {}
};

class QueueManager {
private:
    int facilityId_;
    std::deque<QueueEntry> queue_;
    bool priorityEnabled_;
    int activeServiceCounters_;
    mutable std::mutex queueMutex_;

public:
    explicit QueueManager(int facilityId, int activeCounters = 2, bool priorityEnabled = false);

    const std::string& enqueue(int userId, const std::string& studentName, int priority = 0);
    bool callNext(int counterId, QueueEntry& outServedEntry);
    bool completeService(const std::string& queueId);
    bool cancelQueueEntry(const std::string& queueId);

    int getQueuePosition(const std::string& queueId) const;
    int getPeopleAhead(const std::string& queueId) const;
    size_t getWaitingCount() const;

    void setPriorityEnabled(bool enabled) { priorityEnabled_ = enabled; }
    bool isPriorityEnabled() const { return priorityEnabled_; }
    void setActiveCounters(int counters);
    int getActiveCounters() const { return activeServiceCounters_; }

    std::vector<QueueEntry> getSnapshot() const;
    void clear();
};

} // namespace campusflow
