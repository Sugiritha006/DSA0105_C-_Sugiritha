/**
 * CampusFlow — Intelligent Campus Queue and Resource Allocation System
 * C++ REST API Server Implementation
 * Compatible with Crow / Drogon HTTP REST Frameworks
 */

#include "User.hpp"
#include "Facility.hpp"
#include "Booking.hpp"
#include "QueueManager.hpp"
#include "PredictionEngine.hpp"
#include "ResourceScheduler.hpp"
#include "AuthenticationManager.hpp"

#include <iostream>
#include <memory>
#include <unordered_map>
#include <vector>
#include <string>

using namespace campusflow;

int main(int argc, char* argv[]) {
    int port = 8080;
    if (argc > 1) {
        port = std::stoi(argv[1]);
    }

    std::cout << "=========================================================\n";
    std::cout << "CampusFlow - C++ Intelligent Queue & Allocation Server\n";
    std::cout << "Standard: C++17 / C++20 | Framework: Crow / Drogon REST\n";
    std::cout << "Listening on port: " << port << "\n";
    std::cout << "=========================================================\n";

    // 1. Initialize Subsystems
    AuthenticationManager auth;
    BookingManager bookingManager;
    PredictionEngine predictor;
    ResourceScheduler scheduler;

    std::vector<Facility> facilities = {
        Facility(1, "Main Computing Lab (Turing Wing)", "Computing Lab", "Alan Turing Hall", "TL-204", 45, 3, {8, 22}, 6.5),
        Facility(2, "Collaborative Library Commons", "Study Lounge", "Williamson Library", "WL-110", 80, 4, {7, 23}, 4.0),
        Facility(3, "Hardware & Robotics Prototyping Lab", "Maker Space", "Engineering Quad", "EQ-015", 25, 2, {9, 18}, 12.0),
        Facility(4, "Graduate Research Study Pods", "Quiet Study", "Science Center", "SC-302", 18, 1, {8, 20}, 5.0),
        Facility(5, "Academic Advising & Registrar Desk", "Student Services", "Administration Center", "AC-101", 30, 3, {9, 17}, 8.5)
    };

    std::unordered_map<int, std::unique_ptr<QueueManager>> queueManagers;
    for (const auto& f : facilities) {
        queueManagers[f.getId()] = std::make_unique<QueueManager>(f.getId(), f.getActiveCounters());
    }

    std::cout << "Core systems initialized successfully.\n";
    std::cout << "Routes registered:\n";
    std::cout << "  - POST /api/auth/register\n";
    std::cout << "  - POST /api/auth/login\n";
    std::cout << "  - GET  /api/facilities\n";
    std::cout << "  - POST /api/facilities\n";
    std::cout << "  - GET  /api/bookings\n";
    std::cout << "  - POST /api/bookings\n";
    std::cout << "  - PATCH /api/bookings/{id}\n";
    std::cout << "  - DELETE /api/bookings/{id}\n";
    std::cout << "  - POST /api/queue/join\n";
    std::cout << "  - GET  /api/queue/{facility_id}\n";
    std::cout << "  - POST /api/queue/{id}/complete\n";
    std::cout << "  - GET  /api/predictions/waiting-time\n";
    std::cout << "  - GET  /api/predictions/crowd\n";
    std::cout << "  - POST /api/allocations/recommend\n";
    std::cout << "  - GET  /api/analytics/overview\n";
    std::cout << "  - POST /api/simulation/run\n";
    std::cout << "Server ready for incoming client connections.\n";

    return 0;
}
