#include "QueueManager.hpp"
#include <stdexcept>
#include <algorithm>
#include <sstream>
#include <iomanip>

namespace campusflow {

std::string queueStatusToString(QueueStatus status) {
    switch (status) {
        case QueueStatus::Waiting: return "waiting";
        case QueueStatus::Serving: return "serving";
        case QueueStatus::Completed: return "completed";
        case QueueStatus::Cancelled: return "cancelled";
        default: return "unknown";
    }
}

QueueStatus stringToQueueStatus(const std::string& str) {
    if (str == "waiting") return QueueStatus::Waiting;
    if (str == "serving") return QueueStatus::Serving;
    if (str == "completed") return QueueStatus::Completed;
    if (str == "cancelled") return QueueStatus::Cancelled;
    throw std::invalid_argument("Unknown queue status: " + str);
}

QueueManager::QueueManager(int facilityId, int activeCounters, bool priorityEnabled)
    : facilityId_(facilityId), priorityEnabled_(priorityEnabled),
      activeServiceCounters_(activeCounters) {
    if (activeCounters < 0) {
        throw std::invalid_argument("Service counters cannot be negative");
    }
}

void QueueManager::setActiveCounters(int counters) {
    if (counters < 0) throw std::invalid_argument("Counters cannot be negative");
    activeServiceCounters_ = counters;
}

const std::string& QueueManager::enqueue(int userId, const std::string& studentName, int priority) {
    std::lock_guard<std::mutex> lock(queueMutex_);

    // Generate unique ID
    static int ticketCounter = 100;
    ticketCounter++;
    std::string newId = "Q-" + std::to_string(ticketCounter);

    QueueEntry entry(newId, facilityId_, userId, studentName, priorityEnabled_ ? priority : 0);

    if (priorityEnabled_ && priority > 0) {
        // Priority insertion: higher priority ahead of lower, but FIFO within same priority
        auto it = queue_.begin();
        while (it != queue_.end() && it->status == QueueStatus::Waiting && it->priorityLevel >= priority) {
            ++it;
        }
        queue_.insert(it, entry);
    } else {
        // Standard FIFO
        queue_.push_back(entry);
    }

    return queue_.back().queueId;
}

bool QueueManager::callNext(int counterId, QueueEntry& outServedEntry) {
    std::lock_guard<std::mutex> lock(queueMutex_);
    if (activeServiceCounters_ == 0) {
        return false;
    }

    for (auto& entry : queue_) {
        if (entry.status == QueueStatus::Waiting) {
            entry.status = QueueStatus::Serving;
            entry.assignedCounter = counterId;
            outServedEntry = entry;
            return true;
        }
    }
    return false;
}

bool QueueManager::completeService(const std::string& queueId) {
    std::lock_guard<std::mutex> lock(queueMutex_);
    for (auto& entry : queue_) {
        if (entry.queueId == queueId && entry.status == QueueStatus::Serving) {
            entry.status = QueueStatus::Completed;
            return true;
        }
    }
    return false;
}

bool QueueManager::cancelQueueEntry(const std::string& queueId) {
    std::lock_guard<std::mutex> lock(queueMutex_);
    for (auto& entry : queue_) {
        if (entry.queueId == queueId && entry.status == QueueStatus::Waiting) {
            entry.status = QueueStatus::Cancelled;
            return true;
        }
    }
    return false;
}

int QueueManager::getQueuePosition(const std::string& queueId) const {
    std::lock_guard<std::mutex> lock(queueMutex_);
    int position = 1;
    for (const auto& entry : queue_) {
        if (entry.status == QueueStatus::Waiting) {
            if (entry.queueId == queueId) {
                return position;
            }
            position++;
        }
    }
    return -1; // Not waiting in queue
}

int QueueManager::getPeopleAhead(const std::string& queueId) const {
    int pos = getQueuePosition(queueId);
    return (pos > 0) ? (pos - 1) : 0;
}

size_t QueueManager::getWaitingCount() const {
    std::lock_guard<std::mutex> lock(queueMutex_);
    size_t count = 0;
    for (const auto& entry : queue_) {
        if (entry.status == QueueStatus::Waiting) count++;
    }
    return count;
}

std::vector<QueueEntry> QueueManager::getSnapshot() const {
    std::lock_guard<std::mutex> lock(queueMutex_);
    return std::vector<QueueEntry>(queue_.begin(), queue_.end());
}

void QueueManager::clear() {
    std::lock_guard<std::mutex> lock(queueMutex_);
    queue_.clear();
}

} // namespace campusflow
