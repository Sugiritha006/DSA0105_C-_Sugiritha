import React, { useState } from 'react';
import { User, UserRole, AuditLog, RBACPermissions, getRolePermissions, normalizeRole } from '../types/campus';
import {
  Shield,
  Users,
  UserCheck,
  Check,
  X,
  FileText,
  Search,
  Filter,
  AlertCircle,
  Lock,
  ChevronDown,
  ArrowUpRight,
} from 'lucide-react';

interface UserRoleManagementViewProps {
  users: User[];
  currentUser: User;
  auditLogs: AuditLog[];
  onUpdateUserRole: (userId: number, newRole: UserRole, department?: string) => void;
}

export const UserRoleManagementView: React.FC<UserRoleManagementViewProps> = ({
  users,
  currentUser,
  auditLogs,
  onUpdateUserRole,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<string>('All');
  const [editingUserId, setEditingUserId] = useState<number | null>(null);
  const [editRole, setEditRole] = useState<UserRole>('student');
  const [editDept, setEditDept] = useState<string>('');
  const [notification, setNotification] = useState<string | null>(null);

  const departments = [
    'Computer Science',
    'Electrical & Computer Engineering',
    'Mechanical Engineering',
    'Biomedical Informatics',
    'Academic Services & Registrar',
    'University Libraries',
    'Campus Dining Services',
    'Campus IT & Operations',
  ];

  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.studentIdNumber && u.studentIdNumber.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (u.department && u.department.toLowerCase().includes(searchQuery.toLowerCase()));
    const norm = normalizeRole(u.role);
    const matchesRole =
      selectedRoleFilter === 'All' ||
      (selectedRoleFilter === 'Student' && norm === 'student') ||
      (selectedRoleFilter === 'Faculty' && norm === 'faculty') ||
      (selectedRoleFilter === 'Admin' && norm === 'admin');
    return matchesSearch && matchesRole;
  });

  const handleStartEdit = (user: User) => {
    setEditingUserId(user.id);
    setEditRole(user.role);
    setEditDept(user.department || departments[0]);
  };

  const handleSaveEdit = (userId: number) => {
    onUpdateUserRole(userId, editRole, editDept);
    setEditingUserId(null);
    setNotification(`Permissions updated: User assigned ${editRole.toUpperCase()} role.`);
    setTimeout(() => setNotification(null), 4000);
  };

  const permissionFeatures: { key: keyof RBACPermissions; label: string; desc: string }[] = [
    { key: 'canManageAllQueues', label: 'Global Queue Control', desc: 'Override, create, or clear queues across any campus facility' },
    { key: 'canManageDepartmentQueues', label: 'Department Queue Operations', desc: 'Call next student, mark attendance, and pause/resume line' },
    { key: 'canOverrideBooking', label: 'Appointment Slot Override', desc: 'Manually adjust slot allocations and reservation limits' },
    { key: 'canEditFacilities', label: 'Facility Infrastructure CRUD', desc: 'Add or modify campus facilities, hours, and counters' },
    { key: 'canAccessFullPredictionEngine', label: 'Full Diagnostic Model Tuning', desc: 'Interactive alpha load sensitivity, baseline recalculation' },
    { key: 'canAccessDepartmentPrediction', label: 'Departmental Footfall Analytics', desc: 'Short-term consultation load forecasts and office hours data' },
    { key: 'canAccessRawAnalytics', label: 'Raw Analytics & ML Verification', desc: 'Access 12-point dataset MAE calculation and raw logs' },
    { key: 'canTuneHyperparameters', label: 'Hyperparameter Parameter Control', desc: 'Adjust capacity threshold ratios and model weights' },
    { key: 'canTriggerEmergencyReroute', label: 'Emergency Load Rerouting', desc: 'Broadcast congestion alerts and divert campus traffic' },
    { key: 'canManageUsers', label: 'User RBAC Governance', desc: 'Promote/demote roles, manage student IDs and departments' },
    { key: 'canViewAuditLogs', label: 'Audit Log Inspection', desc: 'Inspect immutable system event trail and security logs' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-purple-100 text-purple-800 border border-purple-200">
              Admin Exclusive
            </span>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">
              User & Role-Based Access Control (RBAC) Governance
            </h1>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Enforce least-privilege security, manage student/faculty/admin permissions, and review audit trail.
          </p>
        </div>
      </div>

      {notification && (
        <div className="flex items-center gap-2 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800 animate-fadeIn">
          <Check className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* RBAC Permission Matrix Reference */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Shield className="w-4 h-4 text-slate-700" />
              Role Permission Matrix & Data Isolation Enforcer
            </h2>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Live authorization boundaries enforced across frontend routes, API endpoints, and Firestore security rules.
            </p>
          </div>
          <span className="text-[10px] font-mono text-slate-600 bg-slate-200/60 px-2 py-1 rounded">
            Security Spec v2.4 (Active)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/75 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-4">System Capability / Capability Flag</th>
                <th className="py-2.5 px-4 text-center">
                  <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-mono text-[10px]">
                    STUDENT
                  </span>
                </th>
                <th className="py-2.5 px-4 text-center">
                  <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 font-mono text-[10px]">
                    FACULTY
                  </span>
                </th>
                <th className="py-2.5 px-4 text-center">
                  <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-mono text-[10px]">
                    ADMIN
                  </span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {permissionFeatures.map((feat) => {
                const sPerm = getRolePermissions('student')[feat.key];
                const fPerm = getRolePermissions('faculty')[feat.key];
                const aPerm = getRolePermissions('admin')[feat.key];

                return (
                  <tr key={feat.key} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-2.5 px-4">
                      <div className="font-medium text-slate-900">{feat.label}</div>
                      <div className="text-[10px] text-slate-500">{feat.desc}</div>
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      {sPerm ? (
                        <Check className="w-4 h-4 text-emerald-600 mx-auto" />
                      ) : (
                        <span className="text-[11px] text-slate-400 font-mono">—</span>
                      )}
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      {fPerm ? (
                        <Check className="w-4 h-4 text-indigo-600 mx-auto" />
                      ) : (
                        <span className="text-[11px] text-slate-400 font-mono">—</span>
                      )}
                    </td>
                    <td className="py-2.5 px-4 text-center">
                      {aPerm ? (
                        <Check className="w-4 h-4 text-purple-600 mx-auto" />
                      ) : (
                        <span className="text-[11px] text-slate-400 font-mono">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* User Management List */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Users className="w-4 h-4 text-slate-700" />
              Campus User Registry ({filteredUsers.length} accounts)
            </h2>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Select any account to reassign roles, update department affiliations, or audit privilege levels.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search name, ID, email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-slate-900"
              />
            </div>

            {/* Role Filter */}
            <select
              value={selectedRoleFilter}
              onChange={(e) => setSelectedRoleFilter(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
            >
              <option value="All">All Roles</option>
              <option value="Student">Students Only</option>
              <option value="Faculty">Faculty Only</option>
              <option value="Admin">Admins Only</option>
            </select>
          </div>
        </div>

        {/* User Table */}
        <div className="overflow-x-auto mt-4">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3">User & Email</th>
                <th className="py-2.5 px-3">Role</th>
                <th className="py-2.5 px-3">Department / Affiliation</th>
                <th className="py-2.5 px-3">Student / Staff ID</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredUsers.map((u) => {
                const isEditing = editingUserId === u.id;
                const normRole = normalizeRole(u.role);

                return (
                  <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-900">{u.name}</div>
                      <div className="text-[11px] text-slate-500 font-mono">{u.email}</div>
                    </td>

                    <td className="py-3 px-3">
                      {isEditing ? (
                        <select
                          value={editRole}
                          onChange={(e) => setEditRole(e.target.value as UserRole)}
                          className="px-2 py-1 text-xs font-medium bg-white border border-slate-300 rounded focus:ring-1 focus:ring-slate-900"
                        >
                          <option value="student">Student</option>
                          <option value="faculty">Faculty</option>
                          <option value="admin">Admin</option>
                        </select>
                      ) : (
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide ${
                            normRole === 'admin'
                              ? 'bg-purple-100 text-purple-800'
                              : normRole === 'faculty'
                              ? 'bg-indigo-100 text-indigo-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {normRole}
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-3">
                      {isEditing ? (
                        <select
                          value={editDept}
                          onChange={(e) => setEditDept(e.target.value)}
                          className="px-2 py-1 text-xs bg-white border border-slate-300 rounded focus:ring-1 focus:ring-slate-900"
                        >
                          {departments.map((d) => (
                            <option key={d} value={d}>
                              {d}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <span className="text-slate-700">{u.department || 'General Campus'}</span>
                      )}
                    </td>

                    <td className="py-3 px-3 font-mono text-[11px] text-slate-600">
                      {u.studentIdNumber || `STF-00${u.id}`}
                    </td>

                    <td className="py-3 px-3 text-right">
                      {isEditing ? (
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleSaveEdit(u.id)}
                            className="px-2.5 py-1 text-[11px] font-medium text-white bg-slate-900 rounded hover:bg-slate-800 transition-colors"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingUserId(null)}
                            className="px-2 py-1 text-[11px] text-slate-600 hover:text-slate-900 transition-colors"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleStartEdit(u)}
                          className="px-2.5 py-1 text-[11px] font-medium text-slate-700 bg-slate-100 rounded hover:bg-slate-200 transition-colors"
                        >
                          Change Role
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Security Audit Log Stream */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-slate-700" />
              Administrative Security Audit Trail
            </h2>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Immutable log of role modifications, queue overrides, and credential authorizations.
            </p>
          </div>
          <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
            Audit Stream Active
          </span>
        </div>

        <div className="divide-y divide-slate-100 mt-3 font-mono text-xs">
          {auditLogs.slice(0, 8).map((log) => (
            <div key={log.id} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-start sm:items-center gap-2">
                <span className="text-[10px] text-slate-400 shrink-0">
                  {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-slate-100 text-slate-700 font-semibold shrink-0">
                  {log.actionType}
                </span>
                <span className="text-slate-800 text-[11px]">{log.details}</span>
              </div>
              <div className="text-[10px] text-slate-500 flex items-center gap-1 shrink-0">
                <span>By:</span>
                <span className="text-slate-700 font-medium">{log.userName}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
