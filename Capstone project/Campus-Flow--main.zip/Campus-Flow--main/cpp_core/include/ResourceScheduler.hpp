#pragma once

#include "Facility.hpp"
#include "Booking.hpp"
#include <string>
#include <vector>

namespace campusflow {

struct SchedulerWeights {
    double availabilityWeight = 0.35; // Preference for higher capacity headroom
    double waitTimeWeight = 0.25;     // Penalty for longer queues
    double demandWeight = 0.20;       // Penalty for high historical congestion
    double utilizationWeight = 0.20;  // Reward for balancing across underutilized facilities
};

struct SlotCandidate {
    int facilityId;
    std::string facilityName;
    std::string category;
    TimeSlot slot;
    int availableCapacity;
    int totalCapacity;
    double predictedWaitMinutes;
    double expectedDemand;
    double utilizationRate;
    double score;
    bool isFeasible;
    std::string reason;
};

struct AllocationRecommendation {
    std::vector<SlotCandidate> rankedCandidates;
    SlotCandidate preferredSlotEvaluation;
    bool preferredSlotFeasible;
    std::vector<SlotCandidate> alternativeRecommendations;
    std::string algorithmUsed; // "WeightedMultiFactor" or "GreedyBaseline"
    std::string comparisonNotes;
};

class ResourceScheduler {
private:
    SchedulerWeights weights_;

public:
    explicit ResourceScheduler(SchedulerWeights weights = SchedulerWeights());

    void setWeights(const SchedulerWeights& w) { weights_ = w; }
    const SchedulerWeights& getWeights() const { return weights_; }

    // Evaluates a candidate slot using weighted multi-factor scoring
    double computeWeightedScore(int availableCapacity, int totalCapacity,
                                double predictedWaitMinutes, double expectedDemand,
                                double utilizationRate) const;

    // Evaluates candidate using pure greedy heuristic (earliest available with highest immediate capacity)
    double computeGreedyScore(int availableCapacity) const;

    // Rank slots and produce alternative recommendations
    AllocationRecommendation recommendSlots(
        const std::vector<Facility>& facilities,
        const std::vector<Booking>& existingBookings,
        int requestedAttendees,
        const TimeSlot& preferredSlot,
        const std::string& preferredCategory = "",
        bool useGreedyBaseline = false) const;
};

} // namespace campusflow
