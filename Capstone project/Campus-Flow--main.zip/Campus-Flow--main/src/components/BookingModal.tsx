import React, { useState } from 'react';
import { Facility, Booking, User } from '../types/campus';
import { X, Calendar, Clock, Users, AlertCircle, CheckCircle2 } from 'lucide-react';

interface BookingModalProps {
  facility: Facility;
  currentUser: User;
  existingBookings: Booking[];
  onClose: () => void;
  onConfirmBooking: (newBooking: {
    facilityId: number;
    facilityName: string;
    date: string;
    startHour: number;
    endHour: number;
    attendeesCount: number;
    notes?: string;
  }) => { success: boolean; message: string };
  onNavigateToAllocator: (facilityId: number) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  facility,
  currentUser,
  existingBookings,
  onClose,
  onConfirmBooking,
  onNavigateToAllocator,
}) => {
  const [date, setDate] = useState('2026-10-23');
  const [startHour, setStartHour] = useState(10);
  const [endHour, setEndHour] = useState(12);
  const [attendeesCount, setAttendeesCount] = useState(1);
  const [notes, setNotes] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Calculate live occupied seats for the selected date and slot
  const currentOccupancy = existingBookings
    .filter(
      (b) =>
        b.facilityId === facility.id &&
        b.status !== 'cancelled' &&
        b.date === date &&
        startHour < b.endHour &&
        b.startHour < endHour
    )
    .reduce((sum, b) => sum + b.attendeesCount, 0);

  const availableSeats = facility.capacity - currentOccupancy;
  const isCapacitySufficient = availableSeats >= attendeesCount;

  // Check if current user already has an active overlapping reservation
  const userOverlapBooking = existingBookings.find(
    (b) =>
      b.userId === currentUser.id &&
      b.status !== 'cancelled' &&
      b.date === date &&
      startHour < b.endHour &&
      b.startHour < endHour
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (startHour >= endHour) {
      setErrorMessage('End time must be after start time.');
      return;
    }

    if (userOverlapBooking) {
      setErrorMessage(
        `Collision: You already have an active booking (${userOverlapBooking.facilityName}) between ${userOverlapBooking.startHour}:00 and ${userOverlapBooking.endHour}:00.`
      );
      return;
    }

    if (!isCapacitySufficient) {
      setErrorMessage(
        `Capacity Exceeded: This slot only has ${availableSeats} free seat(s), but you requested ${attendeesCount}.`
      );
      return;
    }

    const result = onConfirmBooking({
      facilityId: facility.id,
      facilityName: facility.name,
      date,
      startHour,
      endHour,
      attendeesCount,
      notes,
    });

    if (result.success) {
      setSuccessMessage(result.message);
      setTimeout(() => {
        onClose();
      }, 1400);
    } else {
      setErrorMessage(result.message);
    }
  };

  const hourOptions = [];
  for (let h = facility.hours.openHour; h <= facility.hours.closeHour; h++) {
    hourOptions.push(h);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
      <div className="bg-white rounded-xl border border-slate-200 max-w-lg w-full p-6 shadow-xl relative animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-base font-semibold text-slate-900">
              Reserve Facility
            </h3>
            <div className="text-xs text-slate-500 mt-0.5">
              <span>{facility.name}</span>
              <span className="mx-1.5" aria-hidden="true">·</span>
              <span>{facility.roomNumber}</span>
              <span className="mx-1.5" aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">Cap: {facility.capacity}</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {errorMessage && (
            <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <div className="flex-1">
                <div className="font-medium">{errorMessage}</div>
                {!isCapacitySufficient && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onNavigateToAllocator(facility.id);
                    }}
                    className="mt-1.5 font-medium underline text-rose-900 hover:text-rose-950 block text-[11px]"
                  >
                    View recommended alternative slots in Resource Allocator
                  </button>
                )}
              </div>
            </div>
          )}

          {successMessage && (
            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Date Picker */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Booking Date
            </label>
            <div className="relative">
              <input
                type="date"
                value={date}
                min="2026-10-22"
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full text-xs rounded-lg border border-slate-300 py-2 px-3 text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900 focus:border-slate-900"
              />
            </div>
          </div>

          {/* Time Slot Selectors */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Start Time
              </label>
              <select
                value={startHour}
                onChange={(e) => setStartHour(parseInt(e.target.value))}
                className="w-full text-xs rounded-lg border border-slate-300 py-2 px-3 text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
              >
                {hourOptions.slice(0, -1).map((h) => (
                  <option key={h} value={h}>
                    {h.toString().padStart(2, '0')}:00
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                End Time
              </label>
              <select
                value={endHour}
                onChange={(e) => setEndHour(parseInt(e.target.value))}
                className="w-full text-xs rounded-lg border border-slate-300 py-2 px-3 text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
              >
                {hourOptions.filter((h) => h > startHour).map((h) => (
                  <option key={h} value={h}>
                    {h.toString().padStart(2, '0')}:00
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Attendees Count */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Number of Attendees
            </label>
            <input
              type="number"
              min="1"
              max={facility.capacity}
              value={attendeesCount}
              onChange={(e) => setAttendeesCount(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-full text-xs rounded-lg border border-slate-300 py-2 px-3 text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900 font-mono tabular-nums"
              required
            />
          </div>

          {/* Slot Capacity Status Indicator */}
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs">
            <div className="flex items-center justify-between text-slate-700">
              <span className="font-medium">Slot Availability Check:</span>
              <span className="font-mono tabular-nums font-semibold">
                {availableSeats} of {facility.capacity} seats free
              </span>
            </div>
            <div className="w-full bg-slate-200 h-1.5 rounded-full mt-2 overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${
                  currentOccupancy / facility.capacity > 0.8
                    ? 'bg-rose-500'
                    : currentOccupancy / facility.capacity > 0.5
                    ? 'bg-amber-500'
                    : 'bg-emerald-500'
                }`}
                style={{
                  width: `${Math.min(100, (currentOccupancy / facility.capacity) * 100)}%`,
                }}
              />
            </div>
          </div>

          {/* Purpose / Notes */}
          <div>
            <label className="block text-xs font-medium text-slate-700 mb-1">
              Purpose / Study Topic
            </label>
            <input
              type="text"
              placeholder="e.g. CS Senior Design Group Study"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full text-xs rounded-lg border border-slate-300 py-2 px-3 text-slate-800 focus:outline-none focus:ring-1 focus:ring-slate-900"
            />
          </div>

          {/* Footer Controls */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!isCapacitySufficient || !!userOverlapBooking}
              className="px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors whitespace-nowrap"
            >
              Confirm Reservation
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
