# CampusFlow — Intelligent Campus Queue & Resource Allocation System

CampusFlow is an enterprise campus queue and resource allocation system developed in C++17/C++20, MySQL 8.x, and modern responsive web technologies.

---

## 1. Directory Structure

```
cpp_core/
├── CMakeLists.txt                # CMake C++17/20 build specification
├── include/                      # Header declarations
│   ├── AuthenticationManager.hpp # User auth, hashing, and RBAC
│   ├── Booking.hpp               # Bookings, collision detection, and concurrency
│   ├── Facility.hpp              # Facilities, capacity, and operating hours
│   ├── PredictionEngine.hpp      # FIFO wait formulas, crowd forecasting, MAE benchmark
│   ├── QueueManager.hpp          # FIFO queues, priority dispatch, counter assignment
│   ├── ResourceScheduler.hpp     # Weighted multi-factor allocation and alternative slots
│   └── User.hpp                  # Student, FacilityManager, and Administrator classes
├── src/                          # C++ Implementations
│   ├── AuthenticationManager.cpp
│   ├── Booking.cpp
│   ├── Facility.cpp
│   ├── PredictionEngine.cpp
│   ├── QueueManager.cpp
│   ├── ResourceScheduler.cpp
│   ├── User.cpp
│   └── main.cpp                  # REST API Server entry point
├── tests/
│   └── test_scenarios.cpp        # 10 Acceptance scenarios + MAE verification suite
├── database/
│   ├── schema.sql                # Complete MySQL 8.x DDL schema
│   └── seed_data.sql             # Comprehensive campus seed data
└── docs/
    ├── ARCHITECTURE.md           # Architecture diagrams, ER schema, pseudocode
    └── PERFORMANCE_REPORT.md     # Measured MAE accuracy and benchmark results
```

---

## 2. Compilation and Setup Guide

### Windows (MSYS2 UCRT64 or MinGW-w64)
1. Install MSYS2 from [msys2.org](https://www.msys2.org/).
2. Open the **MSYS2 UCRT64** terminal and install the toolchain:
   ```bash
   pacman -Syu
   pacman -S mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-cmake mingw-w64-ucrt-x86_64-ninja
   ```
3. Add `C:\msys64\ucrt64\bin` to your Windows `PATH` environment variable.
4. Clone or open the project folder in VS Code:
   ```cmd
   cd cpp_core
   mkdir build
   cd build
   cmake -G "MinGW Makefiles" ..
   cmake --build .
   ```
5. Execute the test suite and REST server:
   ```cmd
   ./test_scenarios.exe
   ./campusflow_server.exe
   ```

### Linux (Ubuntu 22.04 / 24.04 or Debian)
```bash
sudo apt update
sudo apt install -y build-essential cmake g++ libmysqlclient-dev
cd cpp_core
mkdir -p build && cd build
cmake ..
make -j$(nproc)
./test_scenarios
./campusflow_server
```

---

## 3. MySQL 8.x Database Configuration

1. Log into your MySQL server:
   ```bash
   mysql -u root -p
   ```
2. Run the initialization scripts:
   ```sql
   SOURCE cpp_core/database/schema.sql;
   SOURCE cpp_core/database/seed_data.sql;
   ```
3. Verify table creation:
   ```sql
   USE campusflow;
   SHOW TABLES;
   SELECT * FROM facilities;
   ```

---

## 4. REST API Endpoints

- `POST /api/auth/register` — Register student or manager
- `POST /api/auth/login` — Authenticate and obtain session token
- `GET  /api/facilities` — Retrieve facility catalog and live status
- `POST /api/bookings` — Create non-overlapping facility reservation
- `DELETE /api/bookings/{id}` — Cancel booking and restore seat capacity
- `POST /api/queue/join` — Join FIFO queue and receive ticket
- `GET  /api/queue/{facility_id}` — View active queue tickets and positions
- `GET  /api/predictions/waiting-time` — Get predicted waiting time with confidence interval
- `POST /api/allocations/recommend` — Weighted scoring recommendation for slots
- `POST /api/simulation/run` — Run simulation test scenarios
