#pragma once

#include <string>
#include <vector>

namespace campusflow {

struct OperatingHours {
    int openHour;   // e.g. 8 for 08:00
    int closeHour;  // e.g. 22 for 22:00
};

class Facility {
private:
    int id_;
    std::string name_;
    std::string category_;
    std::string building_;
    std::string roomNumber_;
    int capacity_;
    int activeCounters_;
    OperatingHours hours_;
    bool isOperational_;
    double avgServiceTimeMinutes_;

public:
    Facility(int id, std::string name, std::string category, std::string building,
             std::string roomNumber, int capacity, int activeCounters,
             OperatingHours hours, double avgServiceTimeMinutes);

    int getId() const { return id_; }
    const std::string& getName() const { return name_; }
    const std::string& getCategory() const { return category_; }
    const std::string& getBuilding() const { return building_; }
    const std::string& getRoomNumber() const { return roomNumber_; }
    int getCapacity() const { return capacity_; }
    int getActiveCounters() const { return activeCounters_; }
    OperatingHours getOperatingHours() const { return hours_; }
    bool isOperational() const { return isOperational_; }
    double getAvgServiceTimeMinutes() const { return avgServiceTimeMinutes_; }

    void setCapacity(int cap);
    void setActiveCounters(int counters);
    void setOperational(bool status);
    void setAvgServiceTime(double minutes);

    bool isWithinOperatingHours(int hour) const;
};

} // namespace campusflow
