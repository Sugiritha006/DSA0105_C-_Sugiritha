#pragma once

#include <string>
#include <vector>
#include <memory>
#include <mutex>

namespace campusflow {

enum class BookingStatus {
    Confirmed,
    Completed,
    Cancelled
};

std::string bookingStatusToString(BookingStatus status);
BookingStatus stringToBookingStatus(const std::string& statusStr);

struct TimeSlot {
    int startHour;  // 24-hr format, e.g. 9
    int endHour;    // 24-hr format, e.g. 11
    std::string date; // YYYY-MM-DD

    bool overlapsWith(const TimeSlot& other) const {
        if (date != other.date) return false;
        return (startHour < other.endHour) && (other.startHour < endHour);
    }

    bool isValid() const {
        return startHour >= 0 && startHour < 24 && endHour > startHour && endHour <= 24;
    }
};

class Booking {
private:
    std::string bookingId_; // e.g. "BK-2026-891"
    int userId_;
    int facilityId_;
    TimeSlot slot_;
    int attendeesCount_;
    BookingStatus status_;
    std::string createdAt_;

public:
    Booking(std::string bookingId, int userId, int facilityId,
            TimeSlot slot, int attendeesCount, BookingStatus status = BookingStatus::Confirmed);

    const std::string& getBookingId() const { return bookingId_; }
    int getUserId() const { return userId_; }
    int getFacilityId() const { return facilityId_; }
    const TimeSlot& getTimeSlot() const { return slot_; }
    int getAttendeesCount() const { return attendeesCount_; }
    BookingStatus getStatus() const { return status_; }

    void setStatus(BookingStatus newStatus) { status_ = newStatus; }
    bool isCancelled() const { return status_ == BookingStatus::Cancelled; }
};

class BookingManager {
private:
    std::vector<Booking> bookings_;
    mutable std::mutex bookingMutex_;

public:
    BookingManager() = default;

    // Returns created Booking on success, throws exception on conflict/capacity violation
    Booking createBooking(const std::string& bookingId, int userId, int facilityId,
                          int facilityCapacity, const TimeSlot& slot, int attendeesCount);

    bool cancelBooking(const std::string& bookingId, int requestUserId, bool isAdmin);
    std::vector<Booking> getBookingsByFacility(int facilityId) const;
    std::vector<Booking> getBookingsByUser(int userId) const;
    int getActiveAttendeeCount(int facilityId, const TimeSlot& slot) const;

    const std::vector<Booking>& getAllBookings() const { return bookings_; }
    void clear() { bookings_.clear(); }
};

} // namespace campusflow
