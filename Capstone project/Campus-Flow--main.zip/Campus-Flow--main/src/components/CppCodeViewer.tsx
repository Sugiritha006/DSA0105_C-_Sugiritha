import React, { useState } from 'react';
import { Copy, Check, FileCode, Database, Terminal, FileText, BookOpen } from 'lucide-react';

interface CodeSnippet {
  id: string;
  name: string;
  category: 'C++ Headers' | 'C++ Core' | 'Build & CMake' | 'MySQL 8.x' | 'Documentation';
  language: string;
  path: string;
  content: string;
}

const SNIPPETS: CodeSnippet[] = [
  {
    id: 'queue_manager_cpp',
    name: 'QueueManager.cpp',
    category: 'C++ Core',
    language: 'cpp',
    path: '/cpp_core/src/QueueManager.cpp',
    content: `// CampusFlow C++ FIFO Queue Orchestration
#include "QueueManager.hpp"
#include <stdexcept>
#include <algorithm>

namespace campusflow {

const std::string& QueueManager::enqueue(int userId, const std::string& studentName, int priority) {
    std::lock_guard<std::mutex> lock(queueMutex_);
    static int ticketCounter = 100;
    ticketCounter++;
    std::string newId = "Q-" + std::to_string(ticketCounter);

    QueueEntry entry(newId, facilityId_, userId, studentName, priorityEnabled_ ? priority : 0);

    if (priorityEnabled_ && priority > 0) {
        auto it = queue_.begin();
        while (it != queue_.end() && it->status == QueueStatus::Waiting && it->priorityLevel >= priority) {
            ++it;
        }
        queue_.insert(it, entry);
    } else {
        queue_.push_back(entry); // Strict FIFO Order
    }
    return queue_.back().queueId;
}

bool QueueManager::callNext(int counterId, QueueEntry& outServedEntry) {
    std::lock_guard<std::mutex> lock(queueMutex_);
    if (activeServiceCounters_ == 0) return false;

    for (auto& entry : queue_) {
        if (entry.status == QueueStatus::Waiting) {
            entry.status = QueueStatus::Serving;
            entry.assignedCounter = counterId;
            outServedEntry = entry;
            return true;
        }
    }
    return false;
}
}`,
  },
  {
    id: 'prediction_engine_cpp',
    name: 'PredictionEngine.cpp',
    category: 'C++ Core',
    language: 'cpp',
    path: '/cpp_core/src/PredictionEngine.cpp',
    content: `// Waiting-Time Prediction & Dynamic Crowd Forecasting
#include "PredictionEngine.hpp"
#include <cmath>

namespace campusflow {

double PredictionEngine::calculateBaselineWait(int peopleAhead, double avgServiceTime, int activeCounters) const {
    if (activeCounters <= 0) return -1.0; // Indefinite delay flag
    if (peopleAhead <= 0) return 0.0;
    return (static_cast<double>(peopleAhead) * avgServiceTime) / static_cast<double>(activeCounters);
}

PredictionResult PredictionEngine::predictWaitTime(int peopleAhead, double avgServiceTime, int activeCounters,
                                                   int facilityCapacity, double historicalDemand,
                                                   bool isOperational) const {
    PredictionResult result;
    if (!isOperational || activeCounters <= 0) {
        result.estimatedWaitMinutes = -1.0;
        result.congestion = CongestionLevel::Critical;
        return result;
    }

    double baseline = calculateBaselineWait(peopleAhead, avgServiceTime, activeCounters);
    double ratio = (facilityCapacity > 0) ? (historicalDemand / static_cast<double>(facilityCapacity)) : 1.0;
    result.congestionRatio = ratio;
    result.congestion = classifyCongestion(historicalDemand, facilityCapacity);

    // Context switching & arrival pressure adjustment:
    // T_adjusted = T_baseline * (1.0 + alpha * (demand / capacity))
    double factor = 1.0 + (congestionCorrectionAlpha_ * ratio);
    result.estimatedWaitMinutes = baseline * factor;
    return result;
}

double PredictionEngine::evaluateMAE(const std::vector<DatasetPoint>& testData, double capacity) const {
    double totalError = 0.0;
    for (const auto& dp : testData) {
        PredictionResult pred = predictWaitTime(dp.peopleAhead, dp.avgServiceTime, dp.activeCounters,
                                                static_cast<int>(capacity), dp.historicalDemandRate, true);
        totalError += std::abs(pred.estimatedWaitMinutes - dp.actualObservedWaitMinutes);
    }
    return totalError / static_cast<double>(testData.size());
}
}`,
  },
  {
    id: 'resource_scheduler_cpp',
    name: 'ResourceScheduler.cpp',
    category: 'C++ Core',
    language: 'cpp',
    path: '/cpp_core/src/ResourceScheduler.cpp',
    content: `// Weighted Multi-Factor Scoring vs Greedy Heuristic
#include "ResourceScheduler.hpp"
#include <algorithm>

namespace campusflow {

double ResourceScheduler::computeWeightedScore(int availableCapacity, int totalCapacity,
                                               double predictedWaitMinutes, double expectedDemand,
                                               double utilizationRate) const {
    if (totalCapacity <= 0) return 0.0;

    double availRatio = static_cast<double>(availableCapacity) / static_cast<double>(totalCapacity);
    double waitScore = std::max(0.0, 1.0 - (predictedWaitMinutes / 60.0));
    double demandScore = 1.0 - std::min(1.0, expectedDemand / static_cast<double>(totalCapacity));
    double utilScore = 1.0 - std::min(1.0, utilizationRate);

    return (weights_.availabilityWeight * availRatio) +
           (weights_.waitTimeWeight * waitScore) +
           (weights_.demandWeight * demandScore) +
           (weights_.utilizationWeight * utilScore);
}

double ResourceScheduler::computeGreedyScore(int availableCapacity) const {
    return static_cast<double>(availableCapacity); // Pure raw availability
}
}`,
  },
  {
    id: 'booking_cpp',
    name: 'Booking.cpp',
    category: 'C++ Core',
    language: 'cpp',
    path: '/cpp_core/src/Booking.cpp',
    content: `// Concurrency, Overlap Checks & Capacity Violation Guards
#include "Booking.hpp"
#include <stdexcept>

namespace campusflow {

Booking BookingManager::createBooking(const std::string& bookingId, int userId, int facilityId,
                                      int facilityCapacity, const TimeSlot& slot, int attendeesCount) {
    std::lock_guard<std::mutex> lock(bookingMutex_);

    if (!slot.isValid()) throw std::invalid_argument("Invalid slot: startHour must precede endHour.");

    // 1. Idempotency Check
    for (const auto& b : bookings_) {
        if (b.getBookingId() == bookingId) throw std::runtime_error("Duplicate booking ID violation.");
    }

    // 2. User Double-Booking Overlap Check
    for (const auto& b : bookings_) {
        if (b.getUserId() == userId && !b.isCancelled() && b.getTimeSlot().overlapsWith(slot)) {
            throw std::runtime_error("Student has overlapping booking at the requested time slot.");
        }
    }

    // 3. Strict Capacity Bounds Check
    int currentOccupancy = getActiveAttendeeCount(facilityId, slot);
    if (currentOccupancy + attendeesCount > facilityCapacity) {
        throw std::runtime_error("Capacity violation: Requested seats exceed facility limit.");
    }

    Booking newBooking(bookingId, userId, facilityId, slot, attendeesCount, BookingStatus::Confirmed);
    bookings_.push_back(newBooking);
    return newBooking;
}
}`,
  },
  {
    id: 'cmake_lists',
    name: 'CMakeLists.txt',
    category: 'Build & CMake',
    language: 'cmake',
    path: '/cpp_core/CMakeLists.txt',
    content: `cmake_minimum_required(VERSION 3.16)
project(CampusFlow VERSION 1.0.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

include_directories(\${CMAKE_CURRENT_SOURCE_DIR}/include)

set(CORE_SOURCES
    src/User.cpp
    src/Facility.cpp
    src/Booking.cpp
    src/QueueManager.cpp
    src/PredictionEngine.cpp
    src/ResourceScheduler.cpp
    src/AuthenticationManager.cpp
)

add_library(campusflow_core STATIC \${CORE_SOURCES})

add_executable(campusflow_server src/main.cpp)
target_link_libraries(campusflow_server PRIVATE campusflow_core)

add_executable(test_scenarios tests/test_scenarios.cpp)
target_link_libraries(test_scenarios PRIVATE campusflow_core)

enable_testing()
add_test(NAME AllAcceptanceScenarios COMMAND test_scenarios)`,
  },
  {
    id: 'mysql_schema',
    name: 'schema.sql',
    category: 'MySQL 8.x',
    language: 'sql',
    path: '/cpp_core/database/schema.sql',
    content: `-- MySQL 8.x Normalized DDL Schema for CampusFlow
CREATE DATABASE campusflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campusflow;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) NOT NULL UNIQUE,
    email VARCHAR(128) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('student', 'facility_manager', 'admin') NOT NULL DEFAULT 'student'
) ENGINE=InnoDB;

CREATE TABLE facilities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    category ENUM('Computing Lab', 'Study Lounge', 'Maker Space', 'Quiet Study', 'Student Services') NOT NULL,
    capacity INT NOT NULL CHECK (capacity > 0),
    active_counters INT NOT NULL DEFAULT 1 CHECK (active_counters >= 0),
    is_operational BOOLEAN NOT NULL DEFAULT TRUE,
    avg_service_time_minutes DECIMAL(5,2) NOT NULL DEFAULT 5.00
) ENGINE=InnoDB;

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_reference VARCHAR(32) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    facility_id INT NOT NULL,
    booking_date DATE NOT NULL,
    start_hour INT NOT NULL,
    end_hour INT NOT NULL,
    attendees_count INT NOT NULL DEFAULT 1,
    status ENUM('confirmed', 'completed', 'cancelled') NOT NULL DEFAULT 'confirmed',
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (facility_id) REFERENCES facilities(id)
) ENGINE=InnoDB;

CREATE TABLE queue_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    queue_ticket_id VARCHAR(32) NOT NULL UNIQUE,
    facility_id INT NOT NULL,
    user_id INT NOT NULL,
    student_name VARCHAR(128) NOT NULL,
    status ENUM('waiting', 'serving', 'completed', 'cancelled') NOT NULL DEFAULT 'waiting',
    estimated_wait_minutes DECIMAL(5,1) NOT NULL DEFAULT 0.0,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;`,
  },
  {
    id: 'readme_md',
    name: 'README.md',
    category: 'Documentation',
    language: 'markdown',
    path: '/cpp_core/README.md',
    content: `# CampusFlow C++ Core & MySQL Setup Guide

## Windows (MSYS2 / MinGW-w64)
1. Install MSYS2 and UCRT64 toolchain:
   pacman -S mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-cmake
2. Build via CMake:
   cd cpp_core
   mkdir build && cd build
   cmake -G "MinGW Makefiles" ..
   cmake --build .
3. Run acceptance test suite:
   ./test_scenarios.exe

## Linux (Ubuntu / Debian)
sudo apt install build-essential cmake g++
cd cpp_core && mkdir build && cd build
cmake .. && make -j$(nproc)
./test_scenarios`,
  },
];

export const CppCodeViewer: React.FC = () => {
  const [selectedSnippetId, setSelectedSnippetId] = useState<string>(SNIPPETS[0].id);
  const [copied, setCopied] = useState(false);

  const currentSnippet = SNIPPETS.find((s) => s.id === selectedSnippetId) || SNIPPETS[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(currentSnippet.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const categories = Array.from(new Set(SNIPPETS.map((s) => s.category)));

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            C++ Backend Architecture, CMake & MySQL 8.x Deliverables
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Production C++17/20 algorithm classes, CMakeLists.txt, acceptance test suite, and relational database DDL.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                Copied to Clipboard
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                Copy File Contents
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Code View Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Sidebar File Tree (3 cols) */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 p-4 space-y-4">
          <div className="text-xs font-semibold text-slate-900">
            Repository Source Tree (/cpp_core/)
          </div>

          <div className="space-y-3">
            {categories.map((cat) => (
              <div key={cat} className="space-y-1">
                <div className="text-[10px] font-mono uppercase text-slate-400 font-semibold tracking-wider px-2">
                  {cat}
                </div>
                <div className="space-y-0.5">
                  {SNIPPETS.filter((s) => s.category === cat).map((s) => {
                    const isSelected = s.id === currentSnippet.id;
                    return (
                      <button
                        key={s.id}
                        onClick={() => setSelectedSnippetId(s.id)}
                        className={`w-full text-left px-2.5 py-1.5 text-xs rounded-md font-mono flex items-center justify-between transition-colors ${
                          isSelected
                            ? 'bg-slate-900 text-white font-medium'
                            : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <span className="truncate">{s.name}</span>
                        <span className="text-[10px] opacity-60 ml-2 uppercase">
                          {s.language}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500">
            <div>Standard: C++17 / C++20</div>
            <div>Database: MySQL 8.x InnoDB</div>
            <div>Compiler: GCC 11+ / MinGW-w64</div>
          </div>
        </div>

        {/* Code Content Editor View (8 cols) */}
        <div className="lg:col-span-8 bg-slate-950 rounded-xl border border-slate-800 text-slate-200 overflow-hidden shadow-sm">
          <div className="px-4 py-3 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
              <FileCode className="w-4 h-4 text-emerald-400" />
              <span>{currentSnippet.path}</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400 uppercase bg-slate-800 px-2 py-0.5 rounded">
              {currentSnippet.language}
            </span>
          </div>

          <pre className="p-4 font-mono text-xs overflow-x-auto leading-relaxed max-h-[560px]">
            <code>{currentSnippet.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
