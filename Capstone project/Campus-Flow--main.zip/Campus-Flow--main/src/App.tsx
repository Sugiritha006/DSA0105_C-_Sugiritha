import React, { useState, useEffect } from 'react';
import {
  User,
  Facility,
  Booking,
  QueueTicket,
  ServiceCounter,
  AuditLog,
  SystemConfig,
  UserRole,
  normalizeRole,
  getRolePermissions,
} from './types/campus';
import {
  INITIAL_USERS,
  INITIAL_FACILITIES,
  INITIAL_COUNTERS,
  INITIAL_BOOKINGS,
  INITIAL_QUEUES,
  INITIAL_AUDIT_LOGS,
  INITIAL_CONFIG,
  calculateFIFOEstimatedWait,
} from './services/campusState';
import {
  auth,
  signInWithGoogle,
  signOutUser,
  syncUserProfile,
  getUserProfile,
  persistBooking,
  persistQueueTicket,
  updateQueueTicketInFirestore,
  updateBookingStatusInFirestore,
  persistAuditLog,
  persistFacility,
  persistCounter,
} from './services/firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { Navbar } from './components/Navbar';
import { FacilityCatalog } from './components/FacilityCatalog';
import { BookingModal } from './components/BookingModal';
import { LiveQueueView } from './components/LiveQueueView';
import { PredictionEngineView } from './components/PredictionEngineView';
import { ResourceSchedulerView } from './components/ResourceSchedulerView';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { SimulationSuiteView } from './components/SimulationSuiteView';
import { CppCodeViewer } from './components/CppCodeViewer';
import { UserRoleManagementView } from './components/UserRoleManagementView';
import {
  Calendar,
  Clock,
  MapPin,
  Users,
  CheckCircle,
  XCircle,
  Shield,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';

export default function App() {
  const [availableUsers, setAvailableUsers] = useState<User[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USERS[0]); // Alex Chen (Student)
  const [activeTab, setActiveTab] = useState<string>('facilities');
  const [isFirebaseUser, setIsFirebaseUser] = useState<boolean>(false);

  // Application Data States
  const [facilities, setFacilities] = useState<Facility[]>(INITIAL_FACILITIES);
  const [bookings, setBookings] = useState<Booking[]>(INITIAL_BOOKINGS);
  const [queueTickets, setQueueTickets] = useState<QueueTicket[]>(INITIAL_QUEUES);
  const [serviceCounters, setServiceCounters] = useState<ServiceCounter[]>(INITIAL_COUNTERS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [systemConfig, setSystemConfig] = useState<SystemConfig>(INITIAL_CONFIG);

  // Booking Modal State
  const [bookingFacility, setBookingFacility] = useState<Facility | null>(null);

  // Scheduler Context State (when navigated from booking rejection)
  const [schedulerFacilityId, setSchedulerFacilityId] = useState<number>(1);

  // Firebase Auth State Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser: FirebaseUser | null) => {
      if (fbUser) {
        setIsFirebaseUser(true);
        // Fetch or create Firestore user profile
        let existingProfile = await getUserProfile(fbUser.uid);
        if (!existingProfile) {
          // If admin email, grant admin role; otherwise default to student
          const assignedRole: UserRole =
            fbUser.email === 'antoprincy628@gmail.com' ? 'admin' : 'student';

          const newUser: User = {
            id: Date.now(),
            uid: fbUser.uid,
            username: fbUser.email ? fbUser.email.split('@')[0] : 'user',
            email: fbUser.email || '',
            role: assignedRole,
            studentIdNumber: `STU-AUTH-${Math.floor(1000 + Math.random() * 9000)}`,
            department: assignedRole === 'admin' ? 'Campus IT & Operations' : 'Computer Science',
            name: fbUser.displayName || 'Authorized User',
            avatarUrl: fbUser.photoURL || undefined,
          };

          await syncUserProfile(newUser);
          existingProfile = newUser;
        }

        setCurrentUser(existingProfile);
        setAvailableUsers((prev) => {
          const exists = prev.some((u) => u.uid === fbUser.uid || u.email === existingProfile!.email);
          if (!exists) {
            return [existingProfile!, ...prev];
          }
          return prev.map((u) => (u.email === existingProfile!.email ? existingProfile! : u));
        });

        addAuditEntry(
          'AUTH_LOGIN',
          'SESSION',
          fbUser.uid,
          `Google Sign-in authenticated for ${existingProfile.name} (${existingProfile.role.toUpperCase()}).`
        );
      } else {
        setIsFirebaseUser(false);
      }
    });

    return () => unsubscribe();
  }, []);

  // Enforce authorized tab whenever role changes
  useEffect(() => {
    const norm = normalizeRole(currentUser.role);
    if (norm === 'student') {
      const allowedStudentTabs = ['facilities', 'queues', 'predictions', 'my_bookings'];
      if (!allowedStudentTabs.includes(activeTab)) {
        setActiveTab('facilities');
      }
    } else if (norm === 'faculty') {
      const allowedFacultyTabs = [
        'facilities',
        'queues',
        'predictions',
        'allocator',
        'my_bookings',
        'cpp_code',
      ];
      if (!allowedFacultyTabs.includes(activeTab)) {
        setActiveTab('queues');
      }
    }
  }, [currentUser.role]);

  // Append audit log helper & persist to Firestore
  const addAuditEntry = (actionType: string, entityName: string, entityId: string, details: string) => {
    const newLog: AuditLog = {
      id: `LOG-${(auditLogs.length + 1).toString().padStart(3, '0')}`,
      timestamp: new Date().toISOString(),
      userId: currentUser.id,
      userName: currentUser.name,
      actionType,
      entityName,
      entityId,
      details,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
    persistAuditLog(newLog);
  };

  // Google Sign-In Trigger
  const handleGoogleSignIn = async () => {
    try {
      await signInWithGoogle();
    } catch (err: any) {
      console.warn('Google sign-in completed or cancelled:', err);
    }
  };

  // Google Sign-Out Trigger
  const handleSignOut = async () => {
    await signOutUser();
    setIsFirebaseUser(false);
    setCurrentUser(INITIAL_USERS[0]); // Reset to default Student Alex Chen
    addAuditEntry('AUTH_LOGOUT', 'SESSION', 'local', 'User signed out from Firebase Auth session.');
  };

  // Booking Creation Handler
  const handleConfirmBooking = (payload: {
    facilityId: number;
    facilityName: string;
    date: string;
    startHour: number;
    endHour: number;
    attendeesCount: number;
    notes?: string;
  }) => {
    const targetFacility = facilities.find((f) => f.id === payload.facilityId);
    if (!targetFacility) {
      return { success: false, message: 'Facility not found.' };
    }

    // 1. Check double booking collision for current user
    const userCollision = bookings.find(
      (b) =>
        b.userId === currentUser.id &&
        b.status !== 'cancelled' &&
        b.date === payload.date &&
        payload.startHour < b.endHour &&
        b.startHour < payload.endHour
    );
    if (userCollision) {
      return {
        success: false,
        message: `Collision: You already have a booking (${userCollision.facilityName}) during this time slot.`,
      };
    }

    // 2. Check facility capacity limit
    const currentOccupied = bookings
      .filter(
        (b) =>
          b.facilityId === payload.facilityId &&
          b.status !== 'cancelled' &&
          b.date === payload.date &&
          payload.startHour < b.endHour &&
          b.startHour < payload.endHour
      )
      .reduce((sum, b) => sum + b.attendeesCount, 0);

    if (currentOccupied + payload.attendeesCount > targetFacility.capacity) {
      return {
        success: false,
        message: `Capacity violated: Only ${
          targetFacility.capacity - currentOccupied
        } seats free for this slot.`,
      };
    }

    // 3. Create confirmed booking
    const newBookingId = `BK-2026-${bookings.length + 101}`;
    const newBooking: Booking = {
      id: newBookingId,
      userId: currentUser.id,
      userUid: currentUser.uid,
      userName: currentUser.name,
      facilityId: payload.facilityId,
      facilityName: payload.facilityName,
      date: payload.date,
      startHour: payload.startHour,
      endHour: payload.endHour,
      attendeesCount: payload.attendeesCount,
      status: 'confirmed',
      notes: payload.notes,
      createdAt: new Date().toISOString(),
    };

    setBookings((prev) => [newBooking, ...prev]);
    persistBooking(newBooking);

    addAuditEntry(
      'BOOKING_CREATED',
      'BOOKING',
      newBookingId,
      `Reserved ${payload.facilityName} (${payload.startHour}:00 - ${payload.endHour}:00) for ${payload.attendeesCount} seat(s).`
    );

    return { success: true, message: `Reservation confirmed! Booking ID: ${newBookingId}` };
  };

  // Booking Cancellation Handler
  const handleCancelBooking = (bookingId: string) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === bookingId ? { ...b, status: 'cancelled' } : b))
    );
    updateBookingStatusInFirestore(bookingId, 'cancelled');
    addAuditEntry('BOOKING_CANCELLED', 'BOOKING', bookingId, `Cancelled booking ${bookingId}; freed capacity.`);
  };

  // Queue Join Handler
  const handleJoinQueue = (facilityId: number, priority = 0) => {
    const targetFacility = facilities.find((f) => f.id === facilityId);
    if (!targetFacility) return;

    // Check if user is already waiting in queue for this facility
    const existingTicket = queueTickets.find(
      (t) =>
        t.facilityId === facilityId &&
        (t.userId === currentUser.id || (t.userUid && t.userUid === currentUser.uid)) &&
        (t.status === 'waiting' || t.status === 'serving')
    );
    if (existingTicket) {
      setActiveTab('queues');
      return;
    }

    const currentWaiting = queueTickets.filter(
      (t) => t.facilityId === facilityId && t.status === 'waiting'
    ).length;

    const waitEst = calculateFIFOEstimatedWait(
      currentWaiting,
      targetFacility.avgServiceTimeMinutes,
      targetFacility.activeCounters,
      targetFacility.capacity,
      currentWaiting * 3.0 + 5.0
    );

    const prefixMap: Record<string, string> = {
      'Computing Lab': 'QF',
      'Study Lounge': 'QL',
      Canteen: 'QC',
      'Student Services': 'QA',
      'Maker Space': 'QM',
      'Quiet Study': 'QP',
    };
    const ticketPrefix = prefixMap[targetFacility.category] || 'QT';
    const newTicketId = `${ticketPrefix}-${queueTickets.length + 101}`;

    const newTicket: QueueTicket = {
      id: newTicketId,
      facilityId,
      facilityName: targetFacility.name,
      userId: currentUser.id,
      userUid: currentUser.uid,
      studentName: currentUser.name,
      priorityLevel: priority,
      status: 'waiting',
      estimatedWaitMinutes: waitEst.estimatedWaitMinutes > 0 ? waitEst.estimatedWaitMinutes : 5.0,
      joinedAt: new Date().toISOString(),
    };

    setQueueTickets((prev) => [...prev, newTicket]);
    persistQueueTicket(newTicket);

    addAuditEntry(
      'QUEUE_JOINED',
      'QUEUE',
      newTicketId,
      `Issued ticket ${newTicketId} for ${targetFacility.name} (Est wait: ${newTicket.estimatedWaitMinutes.toFixed(1)}m).`
    );

    setActiveTab('queues');
  };

  // Queue Ticket Cancellation Handler
  const handleCancelQueueTicket = (ticketId: string) => {
    setQueueTickets((prev) =>
      prev.map((t) => (t.id === ticketId ? { ...t, status: 'cancelled' } : t))
    );
    updateQueueTicketInFirestore(ticketId, { status: 'cancelled' });
    addAuditEntry('QUEUE_CANCELLED', 'QUEUE', ticketId, `Cancelled queue ticket ${ticketId}.`);
  };

  // Counter Call Next Ticket Handler (Faculty / Admin)
  const handleCallNextTicket = (facilityId: number, counterNumber: number) => {
    const firstWaiting = queueTickets.find(
      (t) => t.facilityId === facilityId && t.status === 'waiting'
    );
    if (!firstWaiting) return;

    setQueueTickets((prev) =>
      prev.map((t) =>
        t.id === firstWaiting.id
          ? {
              ...t,
              status: 'serving',
              assignedCounter: counterNumber,
              startedAt: new Date().toISOString(),
            }
          : t
      )
    );
    updateQueueTicketInFirestore(firstWaiting.id, {
      status: 'serving',
      assignedCounter: counterNumber,
      startedAt: new Date().toISOString(),
    });

    setServiceCounters((prev) =>
      prev.map((c) =>
        c.facilityId === facilityId && c.counterNumber === counterNumber
          ? { ...c, currentServingTicket: firstWaiting.id }
          : c
      )
    );

    addAuditEntry(
      'QUEUE_DISPATCHED',
      'COUNTER',
      `Counter #${counterNumber}`,
      `Called ticket ${firstWaiting.id} to Station #${counterNumber} by ${currentUser.name}.`
    );
  };

  // Complete Service Handler (Faculty / Admin)
  const handleCompleteService = (ticketId: string) => {
    const ticket = queueTickets.find((t) => t.id === ticketId);
    if (!ticket) return;

    setQueueTickets((prev) =>
      prev.map((t) =>
        t.id === ticketId
          ? { ...t, status: 'completed', completedAt: new Date().toISOString() }
          : t
      )
    );
    updateQueueTicketInFirestore(ticketId, {
      status: 'completed',
      completedAt: new Date().toISOString(),
    });

    setServiceCounters((prev) =>
      prev.map((c) =>
        c.currentServingTicket === ticketId
          ? { ...c, currentServingTicket: undefined }
          : c
      )
    );

    addAuditEntry(
      'QUEUE_COMPLETED',
      'QUEUE',
      ticketId,
      `Completed service for ticket ${ticketId} (${ticket.studentName}).`
    );
  };

  // Toggle Service Counter Status Handler
  const handleToggleCounter = (counterId: number) => {
    let targetFacilityId = 1;
    let nextState = false;

    setServiceCounters((prev) =>
      prev.map((c) => {
        if (c.id === counterId) {
          targetFacilityId = c.facilityId;
          nextState = !c.isActive;
          const updated = {
            ...c,
            isActive: !c.isActive,
            currentServingTicket: !c.isActive ? c.currentServingTicket : undefined,
          };
          persistCounter(updated);
          return updated;
        }
        return c;
      })
    );

    setFacilities((prev) =>
      prev.map((f) => {
        if (f.id === targetFacilityId) {
          const currentActive = serviceCounters.filter(
            (c) => c.facilityId === f.id && c.id !== counterId && c.isActive
          ).length;
          return {
            ...f,
            activeCounters: nextState ? currentActive + 1 : currentActive,
          };
        }
        return f;
      })
    );

    addAuditEntry(
      'COUNTER_STATUS_CHANGE',
      'COUNTER',
      `Counter #${counterId}`,
      `Station toggled to ${nextState ? 'ONLINE' : 'OFFLINE'} by ${currentUser.name}.`
    );
  };

  // Pause / Resume Queue Handler (Faculty / Admin)
  const handlePauseResumeQueue = (facilityId: number, paused: boolean) => {
    const fac = facilities.find((f) => f.id === facilityId);
    addAuditEntry(
      paused ? 'QUEUE_PAUSED' : 'QUEUE_RESUMED',
      'QUEUE',
      `FAC-${facilityId}`,
      `${currentUser.name} (${currentUser.role}) ${paused ? 'paused' : 'resumed'} intake for ${fac?.name || 'facility'}.`
    );
  };

  // Appointment Slot Override Handler (Faculty / Admin)
  const handleOverrideTicketSlot = (ticketId: string, newPriority: number, reason: string) => {
    setQueueTickets((prev) =>
      prev.map((t) => (t.id === ticketId ? { ...t, priorityLevel: newPriority } : t))
    );
    updateQueueTicketInFirestore(ticketId, { priorityLevel: newPriority });
    addAuditEntry(
      'SLOT_OVERRIDE',
      'QUEUE',
      ticketId,
      `Priority override applied to ticket ${ticketId} by ${currentUser.name}. Reason: ${reason}`
    );
  };

  // Update User Role & Department (Admin Only)
  const handleUpdateUserRole = (userId: number, newRole: UserRole, department?: string) => {
    const targetUser = availableUsers.find((u) => u.id === userId);
    if (!targetUser) return;

    const updatedUser: User = {
      ...targetUser,
      role: newRole,
      department: department || targetUser.department,
    };

    setAvailableUsers((prev) => prev.map((u) => (u.id === userId ? updatedUser : u)));
    if (currentUser.id === userId) {
      setCurrentUser(updatedUser);
    }

    syncUserProfile(updatedUser);
    addAuditEntry(
      'RBAC_ROLE_CHANGE',
      'USER',
      `USER-${userId}`,
      `Admin ${currentUser.name} updated ${targetUser.name} to ${newRole.toUpperCase()} (Department: ${updatedUser.department}).`
    );
  };

  // Add Facility Handler (Admin)
  const handleAddNewFacility = (newFacData: Omit<Facility, 'id'>) => {
    const newId = facilities.length + 1;
    const newFac: Facility = {
      ...newFacData,
      id: newId,
    };
    setFacilities((prev) => [...prev, newFac]);
    persistFacility(newFac);

    const newCounters: ServiceCounter[] = [];
    for (let i = 1; i <= newFac.activeCounters; i++) {
      const counter: ServiceCounter = {
        id: serviceCounters.length + i,
        facilityId: newId,
        counterNumber: i,
        counterName: `Station ${i} - ${newFac.name}`,
        isActive: true,
      };
      newCounters.push(counter);
      persistCounter(counter);
    }
    setServiceCounters((prev) => [...prev, ...newCounters]);

    addAuditEntry(
      'FACILITY_ADDED',
      'FACILITY',
      `FAC-${newId}`,
      `Created new facility: ${newFac.name} (${newFac.capacity} seats, ${newFac.activeCounters} counters).`
    );
  };

  // Quick book from recommendation slot
  const handleBookSelectedSlot = (
    facilityId: number,
    slot: { startHour: number; endHour: number; date: string; attendees: number }
  ) => {
    const fac = facilities.find((f) => f.id === facilityId);
    if (!fac) return;
    const res = handleConfirmBooking({
      facilityId,
      facilityName: fac.name,
      date: slot.date,
      startHour: slot.startHour,
      endHour: slot.endHour,
      attendeesCount: slot.attendees,
      notes: 'Scheduled via Intelligent Resource Allocator recommendation',
    });
    if (res.success) {
      setActiveTab('facilities');
    }
  };

  // User's own bookings list
  const userBookings = bookings.filter(
    (b) => b.userId === currentUser.id || (b.userUid && b.userUid === currentUser.uid)
  );

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-slate-900 selection:text-white">
      {/* Navbar with RBAC & Google Auth */}
      <Navbar
        currentUser={currentUser}
        onSelectUser={setCurrentUser}
        availableUsers={availableUsers}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onGoogleSignIn={handleGoogleSignIn}
        onSignOut={handleSignOut}
        isFirebaseUser={isFirebaseUser}
        emergencyActive={systemConfig.emergencyRerouteActive}
      />

      {/* Main Workspace Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Facilities Catalog */}
        {activeTab === 'facilities' && (
          <FacilityCatalog
            facilities={facilities}
            bookings={bookings}
            currentUser={currentUser}
            onOpenBookingModal={(facility) => setBookingFacility(facility)}
            onJoinQueue={(facility) => handleJoinQueue(facility.id)}
            onCancelBooking={handleCancelBooking}
            onAddNewFacility={currentUser.role === 'admin' ? handleAddNewFacility : undefined}
          />
        )}

        {/* Live Queues View */}
        {activeTab === 'queues' && (
          <LiveQueueView
            facilities={facilities}
            queueTickets={queueTickets}
            serviceCounters={serviceCounters}
            currentUser={currentUser}
            onJoinQueue={(facId) => handleJoinQueue(facId)}
            onCancelQueueTicket={handleCancelQueueTicket}
            onCallNextTicket={handleCallNextTicket}
            onCompleteService={handleCompleteService}
            onToggleCounter={handleToggleCounter}
            onPauseResumeQueue={handlePauseResumeQueue}
            onOverrideTicketSlot={handleOverrideTicketSlot}
          />
        )}

        {/* Prediction Engine View (With Role Masking) */}
        {activeTab === 'predictions' && (
          <PredictionEngineView
            facilities={facilities}
            currentUser={currentUser}
            systemConfig={systemConfig}
            onUpdateSystemConfig={(cfg) => setSystemConfig((prev) => ({ ...prev, ...cfg }))}
            onTriggerEmergencyReroute={(active) =>
              setSystemConfig((prev) => ({ ...prev, emergencyRerouteActive: active }))
            }
          />
        )}

        {/* Resource Scheduler View */}
        {activeTab === 'allocator' && (
          <ResourceSchedulerView
            facilities={facilities}
            bookings={bookings}
            initialFacilityId={schedulerFacilityId}
            onBookSelectedSlot={handleBookSelectedSlot}
          />
        )}

        {/* Global Analytics Dashboard */}
        {activeTab === 'analytics' && (
          <AnalyticsDashboard
            facilities={facilities}
            bookings={bookings}
            queueTickets={queueTickets}
            auditLogs={auditLogs}
          />
        )}

        {/* User & Role Management (Admin Only) */}
        {activeTab === 'users' && (
          <UserRoleManagementView
            users={availableUsers}
            currentUser={currentUser}
            auditLogs={auditLogs}
            onUpdateUserRole={handleUpdateUserRole}
          />
        )}

        {/* Simulation Suite */}
        {activeTab === 'simulation' && (
          <SimulationSuiteView facilities={facilities} bookings={bookings} />
        )}

        {/* C++ Core Engine Viewer */}
        {activeTab === 'cpp_code' && <CppCodeViewer />}

        {/* My Bookings View */}
        {activeTab === 'my_bookings' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200">
              <div>
                <h1 className="text-xl font-bold tracking-tight text-slate-900">
                  {normalizeRole(currentUser.role) === 'faculty' ? 'Department Reservations & Office Hours' : 'My Campus Reservations'}
                </h1>
                <p className="text-xs text-slate-500 mt-1">
                  Active and historical room, lab bench, and consultation reservations.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('facilities')}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors"
              >
                + New Reservation
              </button>
            </div>

            {userBookings.length === 0 ? (
              <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-xs text-slate-500">
                You have no active facility reservations. Browse the catalog to book a study pod or lab station.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {userBookings.map((b) => (
                  <div
                    key={b.id}
                    className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-xs font-bold text-slate-900">{b.id}</span>
                        <span
                          className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                            b.status === 'confirmed'
                              ? 'bg-emerald-50 text-emerald-700'
                              : b.status === 'completed'
                              ? 'bg-blue-50 text-blue-700'
                              : 'bg-rose-50 text-rose-700'
                          }`}
                        >
                          {b.status.toUpperCase()}
                        </span>
                      </div>

                      <h3 className="text-sm font-semibold text-slate-900 mt-2">{b.facilityName}</h3>
                      {b.notes && <p className="text-xs text-slate-600 mt-1 italic">"{b.notes}"</p>}

                      <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-3.5 h-3.5 text-slate-400" />
                          <span>Date: <strong className="font-mono text-slate-800">{b.date}</strong></span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>
                            Time Slot:{' '}
                            <strong className="font-mono text-slate-800">
                              {b.startHour.toString().padStart(2, '0')}:00 - {b.endHour.toString().padStart(2, '0')}:00
                            </strong>
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="w-3.5 h-3.5 text-slate-400" />
                          <span>Attendees: <strong className="font-mono text-slate-800">{b.attendeesCount}</strong></span>
                        </div>
                      </div>
                    </div>

                    {b.status === 'confirmed' && (
                      <div className="mt-4 pt-3 border-t border-slate-100 flex justify-end">
                        <button
                          onClick={() => handleCancelBooking(b.id)}
                          className="px-3 py-1 text-xs text-rose-600 hover:text-rose-800 font-medium"
                        >
                          Cancel Booking
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Booking Modal */}
      {bookingFacility && (
        <BookingModal
          facility={bookingFacility}
          currentUser={currentUser}
          existingBookings={bookings}
          onClose={() => setBookingFacility(null)}
          onConfirmBooking={handleConfirmBooking}
          onNavigateToAllocator={(facilityId) => {
            setSchedulerFacilityId(facilityId);
            setActiveTab('allocator');
          }}
        />
      )}

      {/* Single-Line Compact Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>CampusFlow — Intelligent Campus Queue and Resource Allocation System</div>
          <div className="flex items-center gap-4 text-[11px] font-mono text-slate-400">
            <span>Firebase Auth</span>
            <span>·</span>
            <span>Firestore Persistence</span>
            <span>·</span>
            <span>C++ Engine</span>
            <span>·</span>
            <span>RBAC Enforced</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
